#include "TCTypes.h"
#include "tcat_dice_version.h"

#if defined(__APPLE__)
#include <os/log.h>
#pragma once


#if defined(__cplusplus)
namespace tcat
{
extern "C" {
#endif

enum
{
	kTDLFlag_DisableAll		= 0x00000000,
	kTDLFlag_EnableAll		= 0xffffffff,

	kTDLFlag_StreamIndexMask	= 0x0000000f,
	kTDLFlag_IsTransmitStream	= 1 << 4,			// host computer --> device
	kTDLFlag_Streaming			= 1 << 5,

	kTDLFlag_Error				= 1 << 6,
	kTDLFlag_Warning			= 1 << 7,
	kTDLFlag_Info				= 1 << 8,
	kTDLFlag_Verbose			= 1 << 9,

	kTDLFlag_Configuration		= 1 << 10,
	kTDLFlag_StreamSetup		= 1 << 11,
	kTDLFlag_Audio				= 1 << 12,			// ASIO on Windows, CoreAudio on Mac OS X
	kTDLFlag_WDM				= 1 << 13,
	kTDLFlag_MIDI				= 1 << 14,
	kTDLFlag_Ioctl				= 1 << 15,
	kTDLFlag_PAL				= 1 << 16,

	kTDLFlag_Marker				= 1 << 30,
	kTDLFlag_StopLogging		= 1 << 31
};

#define kTDLFlags_Stream( streamType, streamIndex )		\
	(kTDLFlag_Streaming | (((streamType) == 1) ? kTDLFlag_IsTransmitStream : 0) | ((streamIndex) & kTDLFlag_StreamIndexMask))



static inline int32	TDL_OpenConnection( void ) { return 0; };
static inline int32	TDL_CloseConnection( void ) { return 0; };
static inline void	TDL_StdMsg( uint32 flags, uint32 id, int64 dataOne, int64 dataTwo, int64 dataThree, int64 dataFour ) { };
static inline void	TDL_RltMsg( uint32 flags, uint32 id, int64 dataOne, int64 dataTwo, int64 dataThree, int64 dataFour ) { };


static volatile uint32	* volatile g_TDL_Std_Log_Flags;
static volatile uint32	* volatile g_TDL_Rlt_Log_Flags;


#define TDL_ENABLED( flags32 )				1
#define TDL_REALTIME_ENABLED( flags32 )		0

#define TraceVerbose( flags32, message, ...) os_log(OS_LOG_DEFAULT, "VRB:"#message, ##__VA_ARGS__)
#define TraceInfo( flags32, message, ...) os_log(OS_LOG_DEFAULT, "INF:"#message, ##__VA_ARGS__)
#define TraceWarning( flags32, message, ...) os_log(OS_LOG_DEFAULT, "WRN:"#message, ##__VA_ARGS__)
#define TraceError( message, ...) os_log(OS_LOG_DEFAULT, "ERR:"#message, ##__VA_ARGS__)

//#define TDL_ENTRY( flags32, message, dataOne64, dataTwo64, dataThree64, dataFour64 )	\
//																						\
//	if ((((uint32)flags32) & 0) == ((uint32)flags32))				\
//	{																					\
//		TDL_StdMsg( (uint32)flags32, ((kDriverLog_File_ID << 13) | __LINE__ ), (int64)dataOne64, (int64)dataTwo64, (int64)dataThree64, (int64)dataFour64 );	\
//	}

//#define TDL_REALTIME_ENTRY( flags32, message, ...)


//#define TDL_REALTIME_ENTRY( flags32, message, dataOne64, dataTwo64, dataThree64, dataFour64 )	\
//																						\
//	if ((((uint32)flags32) & 0) == ((uint32)flags32))				\
//	{																					\
//		TDL_RltMsg( (uint32)flags32, ((kDriverLog_File_ID << 13) | __LINE__ ), (int64)dataOne64, (int64)dataTwo64, (int64)dataThree64, (int64)dataFour64 );	\
//	}


#if defined(__cplusplus)
} // extern "C"
} // namespace tcat
#endif

// Windows
#elif defined(_WIN32)
#include "trace.h"

#if defined(__TMHFILE)
#include __TMHFILE
#undef __TMHFILE
#endif

#endif

