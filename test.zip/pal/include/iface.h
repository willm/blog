#pragma once
////////////////////////////////////////////////////////////////////////////////

#if 1 // Moved to branding.h
#define STATIC_KSCATEGORY_FFUSB2AUDIO \
    0x485e5651, 0x8247, 0x42c3, 0x83, 0x58, 0x4c, 0xb7, 0x94, 0x8e, 0xdc, 0xed
DEFINE_GUIDSTRUCT("485E5651-8247-42c3-8358-4CB7948EDCED", KSCATEGORY_FFUSB2AUDIO);
#define KSCATEGORY_FFUSB2AUDIO DEFINE_GUIDNAMED(KSCATEGORY_FFUSB2AUDIO)
#else
#include "branding.h"
#endif
////////////////////////////////////////////////////////////////////////////////

#define STATIC_KSPROPERTYSET_FFUSB2Audio\
	0x86c2fd82, 0xc2a0, 0x4637, 0x9c, 0xb5, 0x29, 0x4f, 0xe8, 0xf5, 0xe1, 0x29
DEFINE_GUIDSTRUCT("86C2FD82-C2A0-4637-9CB5-294FE8F5E129", KSPROPERTYSET_FFUSB2Audio);
#define KSPROPERTYSET_FFUSB2Audio DEFINE_GUIDNAMED(KSPROPERTYSET_FFUSB2Audio)

enum { //                                             Get  Set  Target   Property descriptor type        Property value type
	//                                                -----------------------------------------------------------------------
	KSPROPERTY_FFUSB2Audio_UrbSize,               //  Yes  Yes  Filter   KSPROPERTY                      ULONG
	KSPROPERTY_FFUSB2Audio_LockedSampleRate,      //  Yes  No   Filter   KSPROPERTY                      ULONG
	KSPROPERTY_FFUSB2Audio_SupportedSampleRates,  //  Yes  No   Filter   KSPROPERTY                      Variable length array of ULONGs
	KSPROPERTY_FFUSB2Audio_CurrentSampleRate,     //  Yes  Yes  Filter   KSPROPERTY                      ULONG
	KSPROPERTY_FFUSB2Audio_ClockSourceIndex = 10, //  Yes  Yes  Filter   KSPROPERTY                      ULONG
	KSPROPERTY_FFUSB2Audio_ClockSourceInfo  = 11, //  Yes  No   Filter   KSPROPERTY_CLOCK_SOURCE_INFO    KSCLOCK_SOURCE_INFO
	KSPROPERTY_FFUSB2Audio_USBAudioControl	= 20, //  Yes  Yes  Filter   KSPROPERTY_USBAUDIOCONTROL      Variable-length data
	KSPROPERTY_FFUSB2Audio_ChannelName		= 30, //  Yes  No   Pin      KSNODEPROPERTY                  WCHAR[64]
	KSPROPERTY_FFUSB2Audio_UrbSize_Min		= 40, //  Yes  No   Filter   KSPROPERTY                      ULONG
	KSPROPERTY_FFUSB2Audio_StreamStats		= 50, //  Yes  No   Pin      KSPROPERTY                      UsbAudioStreamStats
	KSPROPERTY_FFUSB2Audio_ProcessIDs		= 60, //  Yes  No   Filter   KSPROPERTY                      Variable length array of DWORDs

	KSPROPRTYY_FFUSB2Audio_End
};

////////////////////////////////////////

typedef struct KSPROPERTY_CLOCK_SOURCE_INFO {
	KSPROPERTY Property;
	ULONG ClockSourceIndex;
} KSPROPERTY_CLOCK_SOURCE_INFO;

typedef struct KSCLOCK_SOURCE_INFO
{
    ULONG ClockSourceIndex;
    WCHAR ClockSourceName[32];
    UCHAR ClockSourceEntityID;
    UCHAR ClockSelectorEntityID;
    UCHAR iClockSourceName;
    ULONG Flags;
} KSCLOCK_SOURCE_INFO;

#define KSCLOCK_SOURCE_FLAG_IS_VALID	0x00000010
#define KSCLOCK_SOURCE_FLAG_TYPE_MASK	0x0000000F

enum
{
    KSCLOCK_SOURCE_TYPE_EXTERNAL = 0,
    KSCLOCK_SOURCE_TYPE_INTERNAL_FIXED = 1,
    KSCLOCK_SOURCE_TYPE_INTERNAL_VARIABLE = 2,
    KSCLOCK_SOURCE_TYPE_INTERNAL_PROGRAMMABLE = 3,
};

typedef struct KSPROPERTY_USBAUDIOCONTROL {
	KSPROPERTY Property;
	UCHAR EntityID;
	UCHAR Request;
	UCHAR ControlSelector;
	UCHAR ChannelOrMixerControl;
} KSPROPERTY_USBAUDIOCONTROL;

#define COMPLETION_DELAY_BUCKETS 20

////////////////////////////////////////

enum {
	kEvent_USB_IsocCompletion			= 'isoc', // an isochronous transfer was completed

	kEvent_Pin_StreamHeaderSubmitted	= 'subm', // audio client has submitted a buffer (IOCTL_KS_WRITE_STREAM or READ_STREAM)
	kEvent_Pin_AttemptProcessing		= 'proc', // KsPinAttemptProcessing
	kEvent_Pin_StreamHeaderAdvanced		= 'adva', // pin has copied some data into stream's buffer
	kEvent_Pin_StreamHeaderEjected		= 'ejec', // pin has filled the stream's buffer
	kEvent_Pin_FrameStarvation_Error	= 'strv',
};

typedef struct FFUSB2AUDIO_TELEMETRY_EVENT {
	ULONG32 EventType;
	ULONG32 NumSampleFrames;
	ULONG32 Device;
	ULONG32 PinInstance;				// can be NULL for non-pin events
	ULONG32 StreamHeader;				// address in memory (uniquely identifies the stream)
	ULONG32 PinAvailableInputSamples;	// KsPinGetAvailableByteCount
	ULONG32 PinAvailableOutputSamples;	// KsPinGetAvailableByteCount
} FFUSB2AUDIO_TELEMETRY_EVENT;

// FFUSB2AUDIO_TELEMETRY_EVENTs are delivered via WPP (ETW)
// {BA21A5B5-E85C-4343-B9BF-5F1BF78AE34E}
static const GUID FFUSB2AUDIO_TELEMETRY_EVENT_PROVIDER_ID = { 0xba21a5b5, 0xe85c, 0x4343, { 0xb9, 0xbf, 0x5f, 0x1b, 0xf7, 0x8a, 0xe3, 0x4e } };

// Note - the MessageNumber passed to TraceMessage is a USHORT...
enum {
	kEvent_ASIO_Waiting					= 0xA510,
	kEvent_ASIO_Wokeup					= 0xA511,
	kEvent_ASIO_ConvertInputSamples		= 0xA512,
	kEvent_ASIO_CallbackEnter			= 0xA513,
	kEvent_ASIO_CallbackDone			= 0xA514,
	kEvent_ASIO_ConvertOutputSamples	= 0xA515,
	kEvent_ASIO_SubmitKsBuffers			= 0xA516,
};

static const GUID FFUSB2ASIO_TELEMETRY_EVENT_PROVIDER_ID = { 0xba21a5b5, 0xe85c, 0x4343, { 0xb9, 0xbf, 0x5f, 0x1b, 0xf7, 0x8a, 0xe3, 0x4f } };

////////////////////////////////////////////////////////////////////////////////

#define STATIC_KSEVENTSETID_FFUSB2Audio\
	0x775cee85, 0x4ed, 0x4977, 0xa1, 0xa6, 0xd2, 0x94, 0xe5, 0x48, 0x1, 0x3a
DEFINE_GUIDSTRUCT("775CEE85-04ED-4977-A1A6-D294E548013A", KSEVENTSETID_FFUSB2Audio);
#define KSEVENTSETID_FFUSB2Audio DEFINE_GUIDNAMED(KSEVENTSETID_FFUSB2Audio)

enum {
	KSEVENT_FFUSB2Audio_SampleRate_Changed,
	KSEVENT_FFUSB2Audio_UrbSize_Changed,
	KSEVENT_FFUSB2Audio_USBAudioControlInterrupt,

	KSEVENT_FFUSB2Audio_End
};

////////////////////////////////////////////////////////////////////////////////

#define STATIC_KSMETHODSETID_FFUSB2AUDIO\
	0x9ddee3d3, 0xfdf1, 0x4c0f, 0x9d, 0xd, 0x48, 0x6a, 0x5e, 0xf8, 0x49, 0x2
DEFINE_GUIDSTRUCT("9DDEE3D3-FDF1-4C0F-9D0D-486A5EF84902", KSMETHODSETID_FFUSB2AUDIO);
#define KSMETHODSETID_FFUSB2AUDIO DEFINE_GUIDNAMED(KSMETHODSETID_FFUSB2AUDIO)

enum {
	KSMETHOD_FFUSB2AUDIO_USB_AUDIO_CONTROL,
	KSMETHOD_FFUSB2AUDIO_USB_GET_DESCRIPTOR,
	KSMETHOD_FFUSB2AUDIO_USB_CONTROL_TRANSFER,
};

// Lifted from DDK file usb100.h
#define USB_DEVICE_DESCRIPTOR_TYPE                0x01
#define USB_CONFIGURATION_DESCRIPTOR_TYPE         0x02
#define USB_STRING_DESCRIPTOR_TYPE                0x03
#define USB_INTERFACE_DESCRIPTOR_TYPE             0x04
#define USB_ENDPOINT_DESCRIPTOR_TYPE              0x05

typedef struct KSMETHOD_USB_GET_DESCRIPTOR {
	KSMETHOD Method;
	UCHAR    DescriptorType;	// USB_*_DESCRIPTOR_TYPE
    UCHAR    Index;
    USHORT   LanguageId;
} KSMETHOD_USB_GET_DESCRIPTOR;

typedef struct KSMETHOD_PARAMS_FFUSB2AUDIO_USB_CONTROL_TRANSFER {
	KSMETHOD KsMethod;
	ULONG  PipeHandle;
	ULONG  TransferFlags;
	UCHAR  SetupPacket[8];
} KSMETHOD_PARAMS_FFUSB2AUDIO_USB_CONTROL_TRANSFER;

////////////////////////////////////////////////////////////////////////////////
