//==============================================================================
//####TCAT-SOURCE-HEADER-BEGIN####
//
// This confidential and proprietary source may be used only as authorized
// by a licensing agreement from TC Applied Technologies.
//
// Copyright (c) 2004-2015 TC Applied Technologies
//                         a division of TC Group Americas Ltd.
//                         All rights reserved.
//
// Unauthorized use, duplication or distribution of this source is strictly
// prohibited by law.
//
// The entire notice above must be reproduced on all authorized copies and
// copies may only be made to the extent permitted by a licensing agreement
// from TC Applied Technologies.
//
//####TCAT-SOURCE-HEADER-END####
//==============================================================================
//
//	third party product specific defines
//
//==============================================================================

#ifndef _TCAT_DICE_USB_BRAND_H_
#define _TCAT_DICE_USB_BRAND_H_


//==============================================================================
//
//	product line defines
//
//==============================================================================
//
//	Change this to customize the software for your DICE(tm) product line:
//
//	You have to change all defines to make your driver coexist with other
//	customizations.
//
//	kTCAT_DICE_VENDOR
//	is your natural company name as shown in any software provider information.
#define kTCAT_DICE_VENDOR					Focusrite Audio Engineering Ltd.

//	kTCAT_DICE_VENDOR_SHORT
//	your company short form used for device matching.
//	Textual match for firmware config rom. This cannot contain any
//	non-alphanumeric character! Use underscores instead!
#define kTCAT_DICE_VENDOR_SHORT				Focusrite

//	kTCAT_DICE_VENDOR_UTI
//	uniform type identifier (UTI) string used in Mac OS X bundle identifiers
#define kTCAT_DICE_VENDOR_UTI				tc.tctechnologies

//	kTCAT_DICE_VENDOR_UTI_UNDERSCORE
//	same as kTCAT_DICE_VENDOR_UTI but with periods replaced with underscores
#define kTCAT_DICE_VENDOR_UTI_UNDERSCORE	tc_tctechnologies

//	kTCAT_DICE_USB_VENDOR_ID
//	your vendor identifier assigned by the USB Implementers Forum (USB-IF)
#define kTCAT_DICE_VENDOR_ID			0x1235

//	kTCAT_DICE_USR
//	will be displayed to the end user in any audio or midi driver selection
//	dialogs.
//	This does not necessarily reflect your device name - since more of your
//	devices can be supported by that software. If you plan to only support one
//	device with this software give it a name related to your device.
//	Make sure this name does not exceed 32 character including eventual
//	enumeration additions made by the OS. If you also enable additions like
//	Audio, MIDI, ASIO etc. in tcat_dice_macros.h all needs to fit.
//	This is an OS limitation.
#define kTCAT_DICE_USR						Focusrite USB

//	kTCAT_DICE_DRV
//  will be used to generate filenames and internally used symbolic
//	links.
//	This does not necessarily reflect your device name - since more of your
//	devices can be supported by that software. If you plan to only support one
//	device with this software give it a name related to your device.
#define kTCAT_DICE_DRV						FocusriteUSB

//	kTCAT_DICE_GUID
//	is a GUID that you pick to be distinctive from other DICE products that
//	might be installed in the same system.
//	(Unlike the static firmware magic number that is just an ID to find some
//	information in the binary file.)
// {}
                    

#define kTCAT_DICE_GUID						{0xac4d0455, 0x50d7, 0x4498, {0xb3, 0xcd, 0x9a, 0x41, 0xd1, 0x30, 0xb7, 0x59}}
#define kTCAT_DICE_GUID_PLIST				AC4D0455-50D7-4498-B3CD-9A41D130B759

#define kTCAT_DICE_GEN1DFU_GUID             {0xbc5c8d99, 0x2bdb, 0x46b9, {0xaa, 0xa9, 0xd0, 0xe8, 0x4b, 0xc9, 0x38, 0x7d}}
// {BC5C8D99-2BDB-46B9-AAA9-D0E84BC9387D}

//	kTCAT_MIDI_GUID
#define kTCAT_MIDI_GUID						 {0xe660bbd6, 0x581c, 0x4982, {0x9a, 0x6a, 0xb1, 0xee, 0xe5, 0xbb, 0x67, 0x52}};
// {E660BBD6-581C-4982-9A6A-B1EEE5BB6752}
                                           
#define DFU_INTERFACE_STR L"GEN1DFU"

#define DEVICE_BUSID USB
#define DEVICEID_FORMAT_STRING "USB\\VID_%04X&PID_%04X"

//==============================================================================
//
//	device defines
//
//==============================================================================
//
//	The following defines the USB devices which are supported by this software:
//	You can remove defines you don't need.
//
//	kTCAT_DICE_DEVICEID_*_DESC
//	Defines the device description for each of the products supported by this
//	software. This will only appear at the device install process and then
//	replaced by kTCAT_DICE_USR.
//
//	kTCAT_DICE_DEVICEID_*_PID
//	Defines the USB product identifier for each of the products supported by
//	this software.
//


#define kTCAT_DICE_DEVICEID_1_DESC                "Scarlett 2i2 USB"
#define kTCAT_DICE_DEVICEID_1_PID                     0x8006
 
#define kTCAT_DICE_DEVICEID_2_DESC                "Scarlett 8i6"
#define kTCAT_DICE_DEVICEID_2_PID                     0x8002

#define kTCAT_DICE_DEVICEID_3_DESC                "Scarlett 18i6 USB"
#define kTCAT_DICE_DEVICEID_3_PID                     0x8004

#define kTCAT_DICE_DEVICEID_4_DESC                "Scarlett 2i4 USB"
#define kTCAT_DICE_DEVICEID_4_PID                     0x800a

#define kTCAT_DICE_DEVICEID_5_DESC               "Scarlett 2i2 USB"
#define kTCAT_DICE_DEVICEID_5_PID                    0x8016

#define kTCAT_DICE_DEVICEID_6_DESC               "Scarlett Solo"
#define kTCAT_DICE_DEVICEID_6_PID                    0x801c

#define kTCAT_DICE_DEVICEID_7_DESC				"Scarlett 2i4 USB"
#define kTCAT_DICE_DEVICEID_7_PID					0x8200

#define kTCAT_DICE_DEVICEID_8_DESC				"Scarlett 18i20 USB"
#define kTCAT_DICE_DEVICEID_8_PID					0x8201

#define kTCAT_DICE_DEVICEID_9_DESC				"Scarlett 2i2 USB"
#define kTCAT_DICE_DEVICEID_9_PID					0x8202

#define kTCAT_DICE_DEVICEID_10_DESC				"Scarlett 6i6 USB"
#define kTCAT_DICE_DEVICEID_10_PID					0x8203

#define kTCAT_DICE_DEVICEID_11_DESC				"Scarlett 18i8 USB"
#define kTCAT_DICE_DEVICEID_11_PID					0x8204

#define kTCAT_DICE_DEVICEID_12_DESC				"Scarlett Solo USB"
#define kTCAT_DICE_DEVICEID_12_PID					0x8205

#define kTCAT_DICE_DEVICEID_13_DESC				"Scarlett 6i6 USB"
#define kTCAT_DICE_DEVICEID_13_PID					0x8012

#define kTCAT_DICE_DEVICEID_14_DESC				"Scarlett 18i8 USB"
#define kTCAT_DICE_DEVICEID_14_PID					0x8014

#define kTCAT_DICE_DEVICEID_15_DESC				"Scarlett 18i20 USB"
#define kTCAT_DICE_DEVICEID_15_PID					0x800C

#define kTCAT_DICE_DEVICEID_16_DESC				"Clarett USB-C 2Pre"
#define kTCAT_DICE_DEVICEID_16_PID					0x8206

#define kTCAT_DICE_DEVICEID_17_DESC				"Clarett USB-C 4Pre"
#define kTCAT_DICE_DEVICEID_17_PID					0x8207

#define kTCAT_DICE_DEVICEID_18_DESC				"Clarett USB-C 8Pre"
#define kTCAT_DICE_DEVICEID_18_PID					0x8208

#define kTCAT_DICE_DEVICEID_19_DESC				"iTrack Solo"
#define kTCAT_DICE_DEVICEID_19_PID					0x800E

#define kTCAT_DICE_DEVICEID_20_DESC				"Saffire 6 USB"
#define kTCAT_DICE_DEVICEID_20_PID					0x8008


#define kTCAT_DICE_DEVICEID_21_DESC				"Scarlett 2i2 G3"
#define kTCAT_DICE_DEVICEID_21_PID					0x8210

#define kTCAT_DICE_DEVICEID_22_DESC				"Scarlett Solo G3"
#define kTCAT_DICE_DEVICEID_22_PID					0x8211

#define kTCAT_DICE_DEVICEID_23_DESC				"Scarlett 4i4 G3"
#define kTCAT_DICE_DEVICEID_23_PID					0x8212

#define kTCAT_DICE_DEVICEID_24_DESC				"Scarlett 8i6 G3"
#define kTCAT_DICE_DEVICEID_24_PID					0x8213

#define kTCAT_DICE_DEVICEID_25_DESC				"Scarlett 18i8 G3"
#define kTCAT_DICE_DEVICEID_25_PID					0x8214

#define kTCAT_DICE_DEVICEID_26_DESC				"Scarlett 18i20 G3"
#define kTCAT_DICE_DEVICEID_26_PID					0x8215


// Bit Defines for targeted builds
// Reserve 4 lowest bits for version - expansion info

// RESERVED                                                               BIT0-BIT3
#define kTCAT_DEV_SOLO                 {L"PID_801C",    0x10}           //BIT4
#define kTCAT_DEV_2i2                  {L"PID_8016",    0x20}           //BIT5
#define kTCAT_DEV_2i4                  {L"PID_800A",    0x40}           //BIT6
#define kTCAT_DEV_6i6                  {L"PID_8012",    0x80}           //BIT7
#define kTCAT_DEV_8i6                  {L"PID_8002",    0x100}          //BIT8
#define kTCAT_DEV_18i6                 {L"PID_8004",    0x200}          //BIT9

#define kTCAT_DEV_18i8                 {L"PID_8014",    0x400}          //BIT10
#define kTCAT_DEV_18i20                {L"PID_800C",    0x800}          //BIT11

#define kTCAT_DEV_SOLO_2               {L"PID_8205",    0x1000}         //BIT12
#define kTCAT_DEV_2i2_2                {L"PID_8202",    0x2000}         //BIT13
#define kTCAT_DEV_2i4_2                {L"PID_8200",    0x4000}         //BIT14
#define kTCAT_DEV_6i6_2                {L"PID_8203",    0x8000}         //BIT15
#define kTCAT_DEV_18i8_2               {L"PID_8204",    0x10000}        //BIT16
#define kTCAT_DEV_18i20_2              {L"PID_8201",    0x20000}        //BIT17

#define kTCAT_DEV_2PRE                 {L"PID_8206",    0x40000}        //BIT18
#define kTCAT_DEV_4PRE                 {L"PID_8207",    0x80000}        //BIT19
#define kTCAT_DEV_8PRE                 {L"PID_8208",    0x100000}       //BIT20

#define kTCAT_DEV_ITRACK               {L"PID_800E",    0x200000}        //BIT21
#define kTCAT_DEV_SAFFIRE              {L"PID_8008",    0x400000}        //BIT22

// Room for 4 more devices until expansion requred                      //BIT23-BIT24

#define kTCAT_OSVER_WIN7X86MASK                         0x2000000       //BIT25
#define kTCAT_OSVER_WIN8X86MASK                         0x4000000       //BIT26
#define kTCAT_OSVER_WIN10X86MASK                        0x8000000       //BIT27
#define kTCAT_OSVER_WIN7X64MASK                         0x10000000      //BIT28
#define kTCAT_OSVER_WIN8X64MASK                         0x20000000      //BIT29
#define kTCAT_OSVER_WIN10X64MASK                        0x40000000      //BIT30
// RESERVED                                                               BIT31 reserved to indicate additonial 32bit value regmask002 should be retrived from reg

#define kTCAT_DEVMASK_TAB(tabName)      \
    struct {                            \
            WCHAR *str;                 \
            ULONG mask;                 \
            } tabName[] =               \
                {                       \
                    kTCAT_DEV_SOLO,     \
                    kTCAT_DEV_2i2,      \
                    kTCAT_DEV_2i4,      \
                    kTCAT_DEV_6i6,      \
                    kTCAT_DEV_8i6,      \
                    kTCAT_DEV_18i6,     \
                    kTCAT_DEV_18i8,     \
                    kTCAT_DEV_18i20,    \
                                        \
                    kTCAT_DEV_SOLO_2,   \
                    kTCAT_DEV_2i2_2,    \
                    kTCAT_DEV_2i4_2,    \
                    kTCAT_DEV_6i6_2,    \
                    kTCAT_DEV_18i8_2,   \
                    kTCAT_DEV_18i20_2,  \
                                        \
                    kTCAT_DEV_2PRE,     \
                    kTCAT_DEV_4PRE,     \
                                        \
                    kTCAT_DEV_ITRACK,   \
                    kTCAT_DEV_SAFFIRE,  \
                    kTCAT_DEV_8PRE,     \
                };                      \
//==============================================================================

#endif  // _TCAT_DICE_USB_BRAND_H_
