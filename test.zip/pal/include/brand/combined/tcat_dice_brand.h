//==============================================================================
//####TCAT-SOURCE-HEADER-BEGIN####
//
// This confidential and proprietary source may be used only as authorized
// by a licensing agreement from TC Applied Technologies.
//
// Copyright (c) 2004-2015 TC Applied Technologies
//                         a division of TC Group Americas Ltd.
//                         All rights reserved.
//
// Unauthorized use, duplication or distribution of this source is strictly
// prohibited by law.
//
// The entire notice above must be reproduced on all authorized copies and
// copies may only be made to the extent permitted by a licensing agreement
// from TC Applied Technologies.
//
//####TCAT-SOURCE-HEADER-END####
//==============================================================================
//
//	third party product specific defines
//
//==============================================================================

#ifndef _TCAT_DICE_PCIE_BRAND_H_
#define _TCAT_DICE_PCIE_BRAND_H_


//==============================================================================
//
//	product line defines
//
//==============================================================================
//
//	Change this to customize the software for your DICE(tm) product line:
//
//	You have to change all defines to make your driver coexist with other
//	customizations.
//
//	kTCAT_DICE_VENDOR
//	is your natural company name as shown in any software provider information.
#define kTCAT_DICE_VENDOR					Focusrite Audio Engineering Ltd.

//	kTCAT_DICE_VENDOR_SHORT
//	your company short form used for device matching.
//	Textual match for firmware config rom. This cannot contain any
//	non-alphanumeric character! Use underscores instead!
#define kTCAT_DICE_VENDOR_SHORT				Focusrite

//	kTCAT_DICE_VENDOR_UTI
//	uniform type identifier (UTI) string used in Mac OS X bundle identifiers
#define kTCAT_DICE_VENDOR_UTI				com.focusrite

//	kTCAT_DICE_VENDOR_UTI_UNDERSCORE
//	same as kTCAT_DICE_VENDOR_UTI but with periods replaced with underscores
#define kTCAT_DICE_VENDOR_UTI_UNDERSCORE	com_focusrite

//	kTCAT_DICE_PCI_VENDOR_ID
//	the PCI SIG-assigned identifier for the vendor of the device
#define kTCAT_DICE_VENDOR_ID			0x1CB5

//	kTCAT_DICE_USR
//	will be displayed to the end user in any audio or midi driver selection
//	dialogs.
//	This does not necessarily reflect your device name - since more of your
//	devices can be supported by that software. If you plan to only support one
//	device with this software give it a name related to your device.
//	Make sure this name does not exceed 32 character including eventual
//	enumeration additions made by the OS. If you also enable additions like
//	Audio, MIDI, ASIO etc. in tcat_dice_macros.h all needs to fit.
//	This is an OS limitation.
#define kTCAT_DICE_USR						Focusrite Thunderbolt

//	kTCAT_DICE_DRV
//  will be used to generate filenames and internally used symbolic
//	links.
//	This does not necessarily reflect your device name - since more of your
//	devices can be supported by that software. If you plan to only support one
//	device with this software give it a name related to your device.
#define kTCAT_DICE_DRV						FocusritePCIe

//	kTCAT_DICE_GUID
//	is a GUID that you pick to be distinctive from other DICE products that
//	might be installed in the same system.
//	(Unlike the static firmware magic number that is just an ID to find some
//	information in the binary file.)

#define kTCAT_DICE_GUID						{0x429a7462, 0xf176, 0x411e, {0x8d, 0xa9, 0xae, 0x6c, 0xa, 0x25, 0x80, 0x98}}
#define kTCAT_DICE_GUID_PLIST				429A7462-F176-411E-8DA9-AE6C0A258098

//	kTCAT_MIDI_GUID
#define kTCAT_MIDI_GUID						 {0xe660bbd6, 0x581c, 0x4983, {0x9a, 0x6a, 0xb1, 0xee, 0xe5, 0xbb, 0x67, 0x52}};
// {E660BBD6-581C-4983-9A6A-B1EEE5BB6752}


#define DEVICE_BUSID PCI
#define DEVICEID_FORMAT_STRING "PCI\\VEN_%04X&DEV_%04X"


//==============================================================================
//
//	override defaults found in tcat_dice_defaults.h
//
//==============================================================================

#define kTCAT_DICE_SAVE_OSX_COMPONENT_PKGS	1


//==============================================================================
//
//	device defines
//
//==============================================================================
//
//	The following defines the PCI devices which are supported by this software:
//	You can remove defines you don't need.
//
//	kTCAT_DICE_DEVICE_*_DESC
//	Defines the device description for each of the products supported by this
//	software. This will only appear at the device install process and then
//	replaced by kTCAT_DICE_USR.
//
//	kTCAT_DICE_DEVICE_*_PCI_DEVICE_ID
//	Defines the PCI device identifier for each of the products supported by
//	this software.
//

#define kTCAT_DICE_DEVICEID_1_DESC					Focusrite Thunderbolt
#define kTCAT_DICE_DEVICEID_1_PID					0x0002


//==============================================================================

#endif  // _TCAT_DICE_PCIE_BRAND_H_
