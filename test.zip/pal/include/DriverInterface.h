
#pragma once
// {4E181F68-DCD1-44E3-81EA-47C409669FF7}
//DEFINE_GUID(GUID_FNIAUDIO_DEVICE_IFACE, 0x4e181f68, 0xdcd1, 0x44e3, 0x81, 0xea, 0x47, 0xc4, 0x9, 0x66, 0x9f, 0xf7);
//#define KPCIEAUDIO_PRIVATE_IFACE_GUID				    {0x90bff1cc, 0xfef2, 0x4f80, {0xac, 0xef, 0x1a, 0xfc, 0x5, 0x43, 0x73, 0x87}}
typedef enum { kmMidiFuncGetData = 1, kmMidiFuncPutData } midiFunc_t;
#include "DiceDrvioctl.h"

#define USE_DCP
#define kPageSize (4096)
#define kDcpInterfaceVersion (0x100)

typedef  UINT64 AUDIODEVICEHANDLE;

enum {
    kNotificationClassDCP=0,
    kNotificationClassPAL,
    kNotificationClassHwExcept,
    kNotificationClassDevice,
    kNotificationClassMidiReceived,
    kNotificationClassMidiRequested
};

enum {
    kNotificationClassHwExcept_FatalError = 1,
    kNotificationClassHwExcept_PerformanceWarning,
    kNotificationClassHwExcept_HardwareRemoved,
    kNotificationClassHwExcept_Sleep,
    kNotificationClassHwExcept_Wake,
    kNotificationClassHwExcept_Ready,



};

typedef struct StreamBufferInfo_t
{
    UINT32 FirstAgChan;         // First channel in aggregate stream in this chunk
    UINT32 Channels;
    BUFFERDESC BufferDescriptor[2];
}STREAMBUFFERINFO, *PSTREAMBUFFERINFO;

typedef struct DeviceStreamInfo_t
{
    PSTREAMBUFFERINFO record;
    PSTREAMBUFFERINFO play;
    UINT64    timestamp;
    DeviceStreamInfo_t*  pNext;    // LInk to next stream for aggregation
}DEVICESTREAMINFO, *PDEVICESTREAMINFO, **PPDEVICESTREAMINFO;

#if 0
typedef struct
{
    PMDL        mdlIn;
    PMDL        mdlOut;
    PUCHAR      vaIn;
    PUCHAR      vaOut;
} DEVICESTREAMCONNECTION, *PDEVICESTREAMCONNECTION;
#endif


typedef struct {
    UINT32 FpgaRevision;
    UINT32 MaxChannels;
    UINT32 MaxBuffSize;
    UINT32 SerialLo;
    UINT32 SerialHi;

}DEVICECAPS, *PDEVICECAPS;



#if (__cplusplus)
extern "C"
{
#endif


    // AudioEngine client notification callback
    typedef
        UINT32
        (*PFNIAUDIOROOT_NOTIFY_MSG)(
        IN  PVOID audioDeviceId,
        IN  UINT32 msgClass,
        IN  UINT32 msg
        );

    // AudioEngine client DATA notification callback
    typedef
        VOID
        (*PFNIAUDIOROOT_NOTIFY_AUDIO)(
        IN  PVOID audioDeviceId,
        IN  PDEVICESTREAMINFO pStreamInfo,
        IN BOOLEAN passive
        );

    // MIDI get/put callback
    typedef
        UINT32
        (*PFNIAUDIOROOT_NOTIFY_MIDI)(
        IN  PVOID midiDeviceId,
        IN  UINT8 function,            // Function to perform in callback / get,put, control
        IN  UINT8 port,            // Function to perform in callback / get,put, control
        IN  PUINT32 quadlet,
        IN  UINT8 nQuads
        );

    typedef struct
    {
        UINT8 port;
        PUINT32 pQuad;
        UINT8 nQuads;
    }MIDIQUADREQUEST, *PMIDIQUADREQUEST;

    // Send a DCP command up (to the swroot)
    typedef
        UINT32
        (*PFN_SEND_DCP)(
        PVOID pvObj,
        UINT16 opcodeCategory,
        UINT16 opcodeIndex,
        const void *data,
        size_t dataSize,
        void *response,
        size_t *responseSize);

    typedef VOID(*PINTERFACE_REFERENCE)(PVOID Context);
    typedef VOID(*PINTERFACE_DEREFERENCE)(PVOID Context);


#if (__cplusplus)
};
#endif

// Define a two-way communication structure for the root driver's interface into each client
typedef struct IAudioHardware_t {
    INTERFACE                   InterfaceHeader;
    PVOID                       contextDcp;    // Context info to identify hardware device instance
    PVOID                       contextNotify;      // Context info to identify notification instance in swroot
    PVOID                       contextAudio;        // Context info to identify data-handler instance in swroot
//    PVOID                       contextWdm;
    PVOID                       contextMidi;
    PFN_SEND_DCP                funcDcp;        // Down the stack to hardware, etc.
    PFNIAUDIOROOT_NOTIFY_MSG    funcNotify;
    PFNIAUDIOROOT_NOTIFY_AUDIO  funcAudio;
	LONG						enabled;			// Flag indicating that the interface is ready for use.
} DEVICE_HARDWARE_IFACE, *PDEVICE_HARDWARE_IFACE;


#define DMUS_KEF_PACKAGE_EVENT      0x0002  //  This event is a package. The uData.pPackageEvt

