//==============================================================================
//####TCAT-SOURCE-HEADER-BEGIN####
//
// This confidential and proprietary source may be used only as authorized
// by a licensing agreement from TC Applied Technologies.
//
// Copyright (c) 2014-2015 TC Applied Technologies
//                         a division of TC Group Americas Ltd.
//                         All rights reserved.
//
// Unauthorized use, duplication or distribution of this source is strictly
// prohibited by law.
//
// The entire notice above must be reproduced on all authorized copies and
// copies may only be made to the extent permitted by a licensing agreement
// from TC Applied Technologies.
//
//####TCAT-SOURCE-HEADER-END####
//==============================================================================

#pragma once

#include "dcp_opcodes.h"


//	the struct in the status buffer
struct DicePCIeDriverStatus
{
	volatile tcat::uint64		mSampleTime;
	volatile tcat::uint64		mHostTime;
};



#if defined(__cplusplus)
namespace tcat
{
extern "C" {
#endif


/***************************************************************************************************
 * DCP_CLASS_OSX_DRIVER_PRIVATE
 *
 **************************************************************************************************/

enum
{
	kDcpODP_Version					= 0xF000,	// this API version
	kDcpODP_MinCompatibleAPIVersion	= 0xF000,	// minimum API version that is still compatible with this version
};

//----------------------------------------------------------
// Version command
// Input:		none
// Output:		none
// Return code:	kDcpRsp_success or kDcpRsp_error
//----------------------------------------------------------
#define kDcpODP_Op_Version					0

struct tDcpODP_Version
{
	uint32		ioctlAPIVersion;				// set to kDcpODP_Version
	uint32		ioctlMinCompatibleAPIVersion;	// set to kDcpODP_MinCompatibleAPIVersion
};


//----------------------------------------------------------
// SetConfig command
// Input:		tDcpODP_SetConfig
// Output:		none
// Return code:	kDcpRsp_success or kDcpRsp_error
//----------------------------------------------------------
#define kDcpODP_Op_SetConfig				1

struct tDcpODP_SetConfig
{
	uint64		masterDeviceID;
	uint32		clockSourceID;
	uint32		sampleRate;
	uint32		reserved_01;		// asioBufferSize
	uint32		opMode;

	uint32		hwBufferSize;
	uint32		coreAudioBufferFrameSize;
	uint32		numPlayChannels;
	uint32		numRecordChannels;
};


//----------------------------------------------------------
// GetNewConfig command
// Input:		none
// Output:		tDcpODP_GetNewConfig
// Return code:	kDcpRsp_success or kDcpRsp_error
//----------------------------------------------------------
#define kDcpODP_Op_GetNewConfig				2

struct tDcpODP_GetNewConfig
{
	uint64		masterDeviceID;
	uint32		clockSourceID;
	uint32		sampleRate;
	uint32		reserved_01;		// asioBufferSize
	uint32		opMode;
	uint32		stateChangeOccurred;
	uint32		reserved_02;
};


//----------------------------------------------------------
// EnableStreaming command
// Input:		uint32
// Output:		none
// Return code:	kDcpRsp_success or kDcpRsp_error
//----------------------------------------------------------
#define kDcpODP_Op_EnableStreaming			3


//----------------------------------------------------------
// GetMidiConfig command
// Input:		tDcpODP_GetMidiConfig
// Output:		none
// Return code:	kDcpRsp_success or kDcpRsp_error
//----------------------------------------------------------
#define kDcpODP_Op_GetMidiConfig			4

#define kTCAT_DICE_DEVICES						5
#define kTCAT_DICE_MIDI_BUFFER_SIZE				1024
#define kTCAT_DICE_MAX_MIDI_PORTS_PER_DEVICE	8

struct tMidiBuffer
{
	uint32			midiHead;										///< The location in the MIDI buffer where the next MIDI byte should be stored.
	uint32			midiTail;										///< The location in the MIDI buffer from where the next MIDI byte should be read.
	uint64			midiTimeStamp[kTCAT_DICE_MIDI_BUFFER_SIZE];		///< this is expressed in nanosecond time units
	uint8			midiByte[kTCAT_DICE_MIDI_BUFFER_SIZE];			///< buffer that contains the actual MIDI data
};

struct tDriverMidiBuffers
{
	tMidiBuffer		midiInBuffers[kTCAT_DICE_DEVICES][kTCAT_DICE_MAX_MIDI_PORTS_PER_DEVICE];	///< MIDI In port buffers.
	tMidiBuffer		midiOutBuffers[kTCAT_DICE_DEVICES][kTCAT_DICE_MAX_MIDI_PORTS_PER_DEVICE];	///< MIDI Out Port buffers.
	uint32			midiInEnabled[kTCAT_DICE_DEVICES];
};


struct tMidiPortInfo
{
	char			deviceName[32];
	uint16			nameIndex;			// index for the MIDI port name
	uint16			maxSpeed;			// Bps, standard MIDI is 3125
	uint16			flags;				// flags
	uint16			__pad_0;
};

struct tDeviceMidiInfo
{
	uint64			guid;
	char			deviceName[32];
	uint32			midiBuffersIndex;
	uint16			numInPorts;
	uint16			numOutPorts;
	tMidiPortInfo	ports;

	//\cond
	uint32			__pad_0;
	//\endcond
};

struct tDcpODP_GetMidiConfig
{
	//\cond
	uint32			__pad_0;
	//\endcond
	uint32			numDevices;
	tDeviceMidiInfo	deviceMidiInfo[kTCAT_DICE_DEVICES];
};


//----------------------------------------------------------
// StartMidiOut command
// Input:		kDcpODP_Op_StartMidiOut
// Output:		none
// Return code:	kDcpRsp_success or kDcpRsp_error
//----------------------------------------------------------
#define kDcpODP_Op_StartMidiOut				5

struct tDcpODP_SendMidiOut
{
	uint32		midiPortNum;
};


//**************************************************************************************************

#if defined(__cplusplus)
} // extern "C"
} // namespace tcat
#endif
