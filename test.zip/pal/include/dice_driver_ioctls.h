//==============================================================================
//####TCAT-SOURCE-HEADER-BEGIN####
//
// This confidential and proprietary source may be used only as authorized
// by a licensing agreement from TC Applied Technologies.
//
// Copyright (c) 2008-2014 TC Applied Technologies
//                         a division of TC Group Americas Ltd.
//                         All rights reserved.
//
// Unauthorized use, duplication or distribution of this source is strictly
// prohibited by law.
//
// The entire notice above must be reproduced on all authorized copies and
// copies may only be made to the extent permitted by a licensing agreement
// from TC Applied Technologies.
//
//####TCAT-SOURCE-HEADER-END####
//==============================================================================

#pragma once

#include "tcat.h"
#if defined (_WIN32)
//#include <winioctl.h>
#endif
#if defined(__cplusplus)
namespace tcat
{
#endif


//------------------------------------------------------------------------------
// Ioctl interface
//------------------------------------------------------------------------------

enum
{
	kIoctlAPIVersion				= 0x7000,	// this API version
	kIoctlMinCompatibleAPIVersion	= 0x7000,	// minimum API version that is still compatible with this version
};


enum tIoctl_Method
{
													//	Input							Output
													// --------------------------------------------------------------------
	kIoctl_GetVersion					= 0,		//	none							tIoctl_GetVersion_Response
	kIoctl_DCP_Info						= 1,		//	none							tIoctl_DCP_Info_Response
	kIoctl_DCP_Command					= 2,		//	[variable]						[variable]
	kIoctl_WaitForNotification			= 3,		//  none							tIoctl_WaitForNotification_Response
	kIoctl_NumberOfMethods
};

#define DICE_WIN_CTL_CODE( ioctl )	CTL_CODE( FILE_DEVICE_UNKNOWN, (2048 + ioctl), METHOD_BUFFERED, FILE_ANY_ACCESS )


#if defined(__APPLE__)
enum tUserClientMemoryType
{
	kDicePCIeDriver_Buffer_Status,
	kDicePCIeDriver_Buffer_Input,
	kDicePCIeDriver_Buffer_Output,
	kDicePCIeDriver_Buffer_MIDI,
};

enum
{
	kClientUnknown		= 0,
	kClient32Bit		= 32,
	kClient64Bit		= 64,
};
#endif


// Structures in this file are aligned naturally by ordering any 64 bit quantities first.
// #pragma pack could also be used to force alignment

struct tIoctl_GetVersion_Response
{
	uint32		ioctlAPIVersion;				// set to kIoctlAPIVersion
	uint32		ioctlMinCompatibleAPIVersion;	// set to kIoctlMinCompatibleAPIVersion
	uint64		driverVersion64;				// set to kTCAT_DICE_VERSION64
};


struct tIoctl_DCP_Info_Response
{
	uint32		version;
	uint32		maxTransferSize;
	uint32		reserved_1;						// reserved -- set to zero
	uint32		reserved_2;						// reserved -- set to zero
};


struct tIoctl_DCP_Command_Request_Header
{
	uint64		deviceID;
	uint16		opcodeCategory;
	uint16		opcodeIndex;
	uint32		reserved_1;						// reserved -- set to zero
};


struct tIoctl_DCP_Command_Response_Header
{
	uint32		dcpStatus;
	uint32		responseSize;
};


struct tIoctl_WaitForNotification_Response
{
	uint32		busNotification;
	uint32		deviceDcpNotification;			///< valid if kBusNotification_DeviceDcpNotification
	uint64		deviceID;						///< deviceID of device that the deviceDcpNotification came from
};


#if defined(__cplusplus)
} // namespace tcat
#endif
