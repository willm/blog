/*++

Module Name:

Trace.h

Abstract:

Trace control header file for Focusrite SWROOT KM driver.

Environment:

Kernel mode

--*/

//
// Define the tracing flags.
//
// Tracing GUID - 7268df97-88a4-4ee9-986f-3281c31e70b4
//


#define WPP_CONTROL_GUIDS                               \
    WPP_DEFINE_CONTROL_GUID(                            \
        MODULENAME, (MODULEGUID),                       \
                                                        \
        WPP_DEFINE_BIT(TRACEFLG_ERROR)                   \
        WPP_DEFINE_BIT(TRACEFLG_WARNING)                         \
        WPP_DEFINE_BIT(TRACEFLG_INFORMATION)                     \
        WPP_DEFINE_BIT(TRACEFLG_FUNCTRACE)                  \
        WPP_DEFINE_BIT(TRACEFLG_POWER)                      \
        WPP_DEFINE_BIT(TRACEFLG_RTWDM)                      \
        WPP_DEFINE_BIT(TRACEFLG_WDM)                        \
        WPP_DEFINE_BIT(TRACEFLG_ASIO)                       \
        WPP_DEFINE_BIT(TRACEFLG_RTASIO)                     \
        WPP_DEFINE_BIT(TRACEFLG_PCIEIRQ)                    \
        WPP_DEFINE_BIT(TRACEFLG_PCIEDPC)                    \
        WPP_DEFINE_BIT(TRACEFLG_USBURB)                     \
        WPP_DEFINE_BIT(TRACEFLG_USBIRP)                     \
        WPP_DEFINE_BIT(TRACEFLG_STREAMS)                    \
        WPP_DEFINE_BIT(TRACEFLG_QUEUES)                     \
        WPP_DEFINE_BIT(TRACEFLG_REQUESTS)                   \
        WPP_DEFINE_BIT(TRACEFLG_IOCTL)                      \
        WPP_DEFINE_BIT(TRACEFLG_INTERNALIOCTL)              \
        WPP_DEFINE_BIT(TRACEFLG_PERFORMANCE)                \
        WPP_DEFINE_BIT(TRACEFLG_AUDIOCLIENTS)               \
        WPP_DEFINE_BIT(TRACEFLG_AUDIOCALLBACKS)             \
        WPP_DEFINE_BIT(TRACEFLG_FCP)                        \
        WPP_DEFINE_BIT(TRACEFLG_DEVNOTIFICATIONS)           \
        WPP_DEFINE_BIT(TRACEFLG_TDL)                        \
        WPP_DEFINE_BIT(TRACEFLG_RTTDL)                      \
        WPP_DEFINE_BIT(TRACEFLG_PAL)                        \
        WPP_DEFINE_BIT(TRACEFLG_IHELPER)                    \
        )                             


#define WPP_LEVEL_FLAGS_LOGGER(lvl,flags) \
           WPP_LEVEL_LOGGER(flags)

#define WPP_LEVEL_FLAGS_ENABLED(lvl, flags) \
           (WPP_LEVEL_ENABLED(flags) && WPP_CONTROL(WPP_BIT_ ## flags).Level >= lvl)

#define WPP_LEVEL_FLAGS_RET_LOGGER(lvl,flags,ret) \
           WPP_LEVEL_LOGGER(flags)

#define WPP_LEVEL_FLAGS_RET_ENABLED(lvl,flags,ret) \
           (WPP_LEVEL_ENABLED(flags) && WPP_CONTROL(WPP_BIT_ ## flags).Level >= lvl)

// begin_wpp config 
// CUSTOM_TYPE(SYSTEM_POWER_STATE, ItemEnum(_SYSTEM_POWER_STATE) );
// end_wpp



//MACRO: TraceError
//
//begin_wpp config
//USEPREFIX (TraceError, "%!STDPREFIX!ERROR: ");
//FUNC TraceError{LEVEL=TRACE_LEVEL_ERROR, FLAGS=TRACEFLG_ERROR}(MSG, ...);
//WPP_FLAGS(-public:TraceError);
//end_wpp


//MACRO: TraceVerbose
//
//begin_wpp config
//FUNC TraceVerbose{LEVEL=TRACE_LEVEL_VERBOSE}(FLAGS, MSG, ...);
//WPP_FLAGS(-public:TraceVerbose);
//end_wpp


//MACRO: TraceInfo
//
//begin_wpp config
//FUNC TraceInfo{LEVEL=TRACE_LEVEL_INFORMATION}(FLAGS, MSG, ...);
//WPP_FLAGS(-public:TraceInfo);
//end_wpp


//MACRO: TraceWarning
//
//begin_wpp config
//FUNC TraceWarning{LEVEL=TRACE_LEVEL_WARNING}(FLAGS, MSG, ...);
//WPP_FLAGS(-public:TraceWarning);
//end_wpp


//MACRO: TraceFuncEntry
//
//begin_wpp config
//USEPREFIX (TraceFuncEntry, "%!STDPREFIX!-->");
//FUNC TraceFuncEntry{LEVEL=TRACE_LEVEL_VERBOSE,FLAGS=TRACEFLG_FUNCTRACE}();
//WPP_FLAGS(-public:TraceFuncEntry);
//end_wpp

//MACRO: TraceFuncExit
//
//begin_wpp config
//USEPREFIX (TraceFuncExit, "%!STDPREFIX!<--");
//FUNC TraceFuncExit{LEVEL=TRACE_LEVEL_VERBOSE,FLAGS=TRACEFLG_FUNCTRACE}(RET);
//USESUFFIX (TraceFuncExit, "%!STATUS!",RET);
//WPP_FLAGS(-public:TraceFuncExit);
//end_wpp

//begin_wpp config
//USEPREFIX (TraceExitIfCondition, "%!STDPREFIX!FAILEXIT:");
//FUNC TraceExitIfCondition{LEVEL=TRACE_LEVEL_ERROR, FLAGS=TRACEFLG_ERROR}(EXP,LABEL,RET);
//USESUFFIX (TraceExitIfCondition, " - (%s) failed %!FILE!:%!FUNC!():%!LINE!",szExp);
//end_wpp

//begin_wpp config
//USEPREFIX (TraceAssert, "%!STDPREFIX!TRACEASSERT:");
//FUNC TraceAssert{LEVEL=TRACE_LEVEL_ERROR, FLAGS=TRACEFLG_ERROR}(EXP);
//USESUFFIX (TraceAssert, " - (%s) failed %!FILE!:%!FUNC!():%!LINE!",szExp);
//end_wpp

//begin_wpp config
//USEPREFIX (TraceAssertReturnStatus, "%!STDPREFIX!TRACEASSERT:");
//FUNC TraceAssertReturnStatus{LEVEL=TRACE_LEVEL_ERROR, FLAGS=TRACEFLG_ERROR}(EXP,RET);
//USESUFFIX (TraceAssertReturnStatus, " - (%s) failed. returning %s !FILE!:%!FUNC!():%!LINE!",szExp,szRet);
//end_wpp

#define WPP_LEVEL_FLAGS_EXP_LABEL_RET_PRE(lvl,flags,exp,lbl,ret) if ( ( exp ) ) { PCHAR szExp = #exp; 
#define WPP_LEVEL_FLAGS_EXP_LABEL_RET_POST(lvl,flags,exp,lbl,ret) ;status = ret; goto lbl;}

#define WPP_LEVEL_FLAGS_EXP_LABEL_RET_ENABLED(lvl,flags,exp,lbl,ret) \
    (WPP_LEVEL_ENABLED(flags) && WPP_CONTROL(WPP_BIT_ ## flags).Level >= lvl)

#define WPP_LEVEL_FLAGS_EXP_LABEL_RET_LOGGER(lvl,flags,exp,lbl,ret) \
    WPP_LEVEL_LOGGER(flags)

#define WPP_LEVEL_FLAGS_EXP_PRE(lvl,flags,exp) if (! ( exp ) ) { PCHAR szExp = #exp; 
#define WPP_LEVEL_FLAGS_EXP_POST(lvl,flags,exp) ;}

#define WPP_LEVEL_FLAGS_EXP_ENABLED(lvl,flags,exp) \
    (WPP_LEVEL_ENABLED(flags) && WPP_CONTROL(WPP_BIT_ ## flags).Level >= lvl)

#define WPP_LEVEL_FLAGS_EXP_LOGGER(lvl,flags,exp) \
    WPP_LEVEL_LOGGER(flags)

#define WPP_LEVEL_FLAGS_EXP_RET_PRE(lvl,flags,exp,ret) if (! ( exp ) ) { PCHAR szExp = #exp; PCHAR szRet= #ret; 
#define WPP_LEVEL_FLAGS_EXP_RET_POST(lvl,flags,exp,ret) ;return ret;}

#define WPP_LEVEL_FLAGS_EXP_RET_ENABLED(lvl,flags,exp,ret) \
    (WPP_LEVEL_ENABLED(flags) && WPP_CONTROL(WPP_BIT_ ## flags).Level >= lvl)

#define WPP_LEVEL_FLAGS_EXP_RET_LOGGER(lvl,flags,exp,ret) \
    WPP_LEVEL_LOGGER(flags)



