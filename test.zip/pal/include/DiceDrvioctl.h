//==============================================================================
//####TCAT-SOURCE-HEADER-BEGIN####
//
// This confidential and proprietary source may be used only as authorized
// by a licensing agreement from TC Applied Technologies.
//
// Copyright (c) 2007-2014 TC Applied Technologies
//                         a division of TC Group Americas Ltd.
//                         All rights reserved.
//
// Unauthorized use, duplication or distribution of this source is strictly
// prohibited by law.
//
// The entire notice above must be reproduced on all authorized copies and
// copies may only be made to the extent permitted by a licensing agreement
// from TC Applied Technologies.
//
//####TCAT-SOURCE-HEADER-END####
//==============================================================================

#ifndef __DiceDrvioctl__h_
#define __DiceDrvioctl__h_

//#include <winnt.h>
#include "tcat.h"
#if defined(USB)
#include "usb/tcat_dice_defaults.h"
#elif defined(PCIE)
#include "pcie/tcat_dice_defaults.h"
#else
#error MUST #define one of USB or 1394!!!
#endif
#include "tcat_dice.h"
#include "tcat_dice_win.h"


typedef union
{
    UINT32 p32;
    UINT64 p64;
}P6432;

#ifndef NTSTATUS
typedef LONG NTSTATUS;
#endif
using namespace tcat;

namespace tcat
{

#define	MAX_STREAMS			(kTCAT_DICE_SUPPORTED_DEVICES * kTCAT_DICE_RX) ///< Aggregate total number of streams supported by the interface.

#define MAX_ASIO_SEQUENCES	(MAX_STREAMS * kTCAT_DICE_MAX_CHANNELS_PER_STREAM)

// defines related with MIDI 
#define DEVICE_TYPE_STREAM_MIDI			0x02
#define DEVICE_TYPE_STREAM_MIDIOUT		0x12
#define DEVICE_TYPE_STREAM_MIDIIN		0x22

// defines related with WDM 
#define DEVICE_TYPE_STREAM_AUDIO		0x01
#define DEVICE_TYPE_STREAM_AUDIOINOUT	0x31
#define WDM_CHANNEL_NOT_MAPPED			-1


#define DICE_MAX_NUM_SEQUENCES			256	// max sequence number


//
// WDM Ioctl interface (audio and MIDI)
//

enum
{
	kWDM_IoctlAPIVersion = 0x9002,		// increment this whenever there is a change to the WDM Ioctl codes or in/out structures
	kMIDI_IoctlAPIVersion = 0x8000,
};

// audio only
enum tWdmIoctl
{
													//	Input							Output
													// --------------------------------------------------------------------
	kWdmIoctl_GetAPIVersion				 = 100,		//	none							DICE_API_VERSION

	kWdmIoctl_SetKsAudioStreamInfo				 = 102,		//	DICE_KSAUDIO_STREAM_INFO			DICE_KSAUDIO_STREAM_INFO
	kWdmIoctl_ClearKsAudioStreamInfo			 = 103,		//	ULONG							none
	kWdmIoctl_GetDeviceInfo				 = 104,		//	DICE_GET_DEVICE_INFO			DICE_GET_DEVICE_INFO
	kWdmIoctl_SetSpeakerConfig			 = 105,		//	ULONG							none
	kWdmIoctl_AudioGetCaps				 = 107,		//	ULONG							ULONG
	kWdmIoctl_AudioClearCaps			 = 108,		//	ULONG							ULONG
	kWdmIoctl_RegisterPCAdapter			 = 109,		//	PVOID							-

};

// midi only
enum tMidiIoctl
{
													//	Input							Output
													// --------------------------------------------------------------------
	kMidiIoctl_GetAPIVersion			= 150,		//	none							DICE_API_VERSION

	kMidiIoctl_GetDeviceIdInfo			= 151,		//	DICE_MIDI_DEVICE_ID_INFO		DICE_MIDI_DEVICE_ID_INFO
	kMidiIoctl_CallbackInfo				= 152,		//	DICE_MIDI_CALLBACK_INFO			DICE_MIDI_CALLBACK_INFO
};

#define DFU_CTL_CODE( code )	CTL_CODE( FILE_DEVICE_UNKNOWN, code, METHOD_BUFFERED, FILE_ANY_ACCESS )
#define DFU_CTL_DECODE( code )	(((code>>2)&0x7fff))

// dfu only
enum tDfuIoctl
{
    //	Input							Output
    // --------------------------------------------------------------------
    kDfuIoctl_Start = 300,
    kDfuIoctl_Stop,
    kDfuIoctl_ControlRead,
    kDfuIoctl_ControlWrite,
    kDfuIoctl_GetDescriptor,
    kDfuIoctl_GetMode,
    kDfuIoctl_DeviceListen,
    kDfuIoctl_DeviceUnListen,

};

typedef enum tDfuModes
{
    kDfuModeInvalid = 0,
    kDfuModeRuntime,
    kDfuModeDfu,
}DfuModes_t;


enum tWdmStreamType
{
	kWdmStream_Capture = 0,
	kWdmStream_Render = 1,
	kWdmStream_Ac3 = 2,
    kWdmStream_Close=3,
};

#pragma pack(1)

typedef
VOID
(*PDICE_PUT_MIDI_IN_BYTE_ROUTINE) (	// We will call this routine
	PVOID context,					//  at DISPATCH_LEVEL
	UCHAR midiByte,
	LONGLONG timeStamp
);

typedef
NTSTATUS
(*PDICE_ENABLE_MIDI_PLAYREC_ROUTINE) ( //Will be called at PASSIVE LEVEL
	PVOID context,	
	PVOID deviceContext, 
	ULONG sequenceSubIndexToUse, 
	BOOLEAN enable 
);


typedef
NTSTATUS
(*PDICE_START_MIDI_OUT_ROUTINE) (void *context, UINT32 portNo);    //Will be called at DISPATCH_LEVEL

typedef void
(*PDICE_QUEUE_AUDIO_DATA_ROUTINE) (void *context, PCHAR pData, UINT32 dataLength);

typedef
NTSTATUS
(*PDICE_ENABLE_PLAYREC_ROUTINE) ( //Will be called at PASSIVE LEVEL
	void *context,
	ULONG state
	);

typedef
void
(*PDICE_DATA_USED_ROUTINE) ( //Will be called at DISPATCH_LEVEL
	PVOID context,
	ULONG dataUsed
);

typedef struct
{
	ULONG		samplingRate;				// current sample rate in 1394 driver
	ULONG		sampleRateChangeAllowed;	// is sample rate change allowed by CPL and OS platform
	ULONG		inChans;
	ULONG		outChans;
	ULONG		bps;
	ULONG		pid;					//wdm device context
	bool		bRemoved;				// Device has been removed
	UINT32		wdmPairs;				// bitmap of enabled wdm pairs: [31..16]=16 output pairs;[15..0]16 input pairs
} DICE_GET_DEVICE_INFO, *PDICE_GET_DEVICE_INFO;

typedef
NTSTATUS
(*PDICE_FORMAT_CHANGE_CALLBACK) ( //Will be called at DISPATCH_LEVEL
	PVOID pv,
	PDICE_GET_DEVICE_INFO DeviceInfo
);


struct DICE_API_VERSION
{
	uint32		driverVersion32;	///< returns kTCAT_DICE_VERSION32
	uint32		ioctlAPIVersion;	///< returns kWDM_IoctlAPIVersion or kMIDI_IoctlAPIVersion
};


struct DICE_KSAUDIO_STREAM_INFO
{
	PDICE_QUEUE_AUDIO_DATA_ROUTINE	pfnQueueDataCallback; 
	PDICE_ENABLE_PLAYREC_ROUTINE	pfnSetStateCallback; 
	PDICE_DATA_USED_ROUTINE			pfnDataUsedCallback;
	PVOID		pCallbackContext;
	SHORT		numChannels;				// the actual number of channels that the STREAMS driver will be sending
	SHORT		firstChanInStream;		// the offset in the DMA frame for the first channel
	ULONG		bitsPerSample;			// the actual number of bits that the STREAMS driver will be sending/receiving
	ULONG		streamType;
	ULONG		samplingRate;
	PVOID		pWdmDeviceContext;		// this will point to WDM device object that root driver has created
	PVOID		pDataBuffer;			//actual DMA buffer pointer
	PVOID		pClientContext;
	ULONG		dataBufferSamples;	// Number of samples per port->Notify (driver client to call GetPosition) 
};


typedef struct
{
	PDICE_FORMAT_CHANGE_CALLBACK	pfnFormatChangeCallback;
	PVOID							pWdmFormatChangeContext;
	PVOID							pWdmAdapterInstance;
	PVOID							pdoChild;
	PVOID							pAudioDevice;
	DICE_GET_DEVICE_INFO			deviceInfo;

} WDM_REGISTER_PCADAPTER, *PWDM_REGISTER_PCADAPTER;

struct DICE_SET_SPEAKER_CONFIG
{
	PVOID		pWdmDeviceContext;
	UINT32		speakerConfig;
};


struct DICE_CLEAR_INFO
{
	PVOID pClientContext;
};


typedef struct
{
    HANDLE  Buf1EventHandle;
    HANDLE  Buf2EventHandle;
    HANDLE  HardwareRemovalHandle;
}ASIOUSERHANDLESTRUCT, *PASIOUSERHANDLESTRUCT;

typedef struct
{
    UCHAR   type;
    UCHAR   index;
    UINT16  lang;
}USBDESCRIPTORREQUEST, *PUSBDESCRIPTORREQUEST;

#pragma pack()



//--------------------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------------------
//
// ASIO Ioctl interface
//
//--------------------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------------------

#define ASIO_CTL_CODE( code )	CTL_CODE( FILE_DEVICE_UNKNOWN, code, METHOD_BUFFERED, FILE_ANY_ACCESS )
#define ASIO_CTL_DECODE( code )	(((code>>2)&0x7fff))

typedef tcat::uint64 CLIENTHANDLE;

enum
{
	kASIO_IoctlAPIVersion	= 0x6014,		// increment this whenever there is a change to the ASIO Ioctl codes or in/out structures
};

enum tAsioIoctl
{
											//	Input							Output
											// --------------------------------------------------------------------
    kAsioIoctl_GetAPIVersion    = 0x200,		//	none							DICE_ASIO_API_VERSION_PARAM
	kAsioIoctl_Info				= 0x201,		//	none							DICE_ASIO_INFO_PARAM
	kAsioIoctl_Init				= 0x202,		//	DICE_ASIO_INIT_PARAM			DICE_ASIO_INIT_PARAM
	kAsioIoctl_DeInit			= 0x203,		//	DICE_ASIO_COMMAND_PARAM			DICE_ASIO_COMMAND_PARAM
	kAsioIoctl_Alloc			= 0x204,		//	DICE_ASIO_ALLOC_PARAM			DICE_ASIO_ALLOC_PARAM
	kAsioIoctl_Free				= 0x205,		//	DICE_ASIO_COMMAND_PARAM			DICE_ASIO_COMMAND_PARAM
	kAsioIoctl_Start			= 0x206,		//	DICE_ASIO_COMMAND_PARAM			DICE_ASIO_COMMAND_PARAM
	kAsioIoctl_Stop				= 0x207,		//	DICE_ASIO_COMMAND_PARAM			DICE_ASIO_COMMAND_PARAM
	kAsioIoctl_GetBufferSize	= 0x208,		//	DICE_ASIO_GET_BUFFER_SIZE		DICE_ASIO_GET_BUFFER_SIZE
	kAsioIoctl_SetBufferSize	= 0x209,		//	DICE_ASIO_SET_BUFFER_SIZE		DICE_ASIO_SET_BUFFER_SIZE
	kAsioIoctl_CanSampleRate	= 0x210,		//	DICE_ASIO_SET_SAMPLE_RATE		DICE_ASIO_SET_SAMPLE_RATE
	kAsioIoctl_SetSampleRate	= 0x211,		//	DICE_ASIO_SET_SAMPLE_RATE		DICE_ASIO_SET_SAMPLE_RATE
// New
    kAsioIoctl_AwaitStreamCallback = 0x212,     //  DICE_ASIO_COMMAND_PARAM         DICE_STREAMIO_COMPLETION
    kAsioIoctl_RegisterRemovalEvent = 0x213,     //  DICE_ASIO_REGISTER_REMOVAL_EVENT
    kAsioIoctl_CancelStreamCallbacks = 0x214,     //  DICE_ASIO_COMMAND_PARAM         DICE_STREAMIO_COMPLETION

};


#ifndef __ASIO_H

typedef long ASIOError;

enum {
	ASE_OK = 0,					// This value will be returned whenever the call succeeded
	ASE_SUCCESS = 0x3f4847a0,	// unique success return value for ASIOFuture calls
	ASE_NotPresent = -1000,		// hardware input or output is not present or available
	ASE_HWMalfunction,			// hardware is malfunctioning (can be returned by any ASIO function)
	ASE_InvalidParameter,		// input parameter invalid
	ASE_InvalidMode,			// hardware is in a bad mode or used in a bad mode
	ASE_SPNotAdvancing,			// hardware is not running when sample position is inquired
	ASE_NoClock,				// sample clock or rate cannot be determined or is not present
	ASE_NoMemory				// not enough memory for completing the request
};

#endif  // __ASIO_H


struct DICE_ASIO_API_VERSION_PARAM
{
	uint32		driverVersion32;	///< returns kTCAT_DICE_VERSION32
	uint32		ioctlAPIVersion;	///< returns kASIO_IoctlAPIVersion
};

#if 0
struct ASIO_SHARED_STATE
{
	void Reset()
	{
		doubleBufferIndex = 0;
		samplePosition = 0;
		crossBoundaryTimeNs = 0;
		numEventsRequestedByDriver = 0;
		numEventsServicedToDriver = 0;
	};

	uint32		doubleBufferIndex;
	uint32		unused_pad_0;
	uint64 		samplePosition;
	uint64		crossBoundaryTimeNs;
	uint32		numEventsRequestedByDriver;
	uint32		numEventsServicedToDriver;
//    ISOCH_STREAM_INFO streamInfo;
};
#endif
enum
{
    kCbWaitEvt_AudioData = 1,
    kCbWaitEvt_Reset,
    kCbWaitEvt_Resync,
    kCbWaitEvt_LatenciesChanged,
    kCbWaitEvt_DeviceRemoved,
    kCbWaitEvt_SamplerateChanged
};


typedef struct
{
    UINT64 mdlIn;
    UINT64 mdlOut;
    UINT64 vaIn;
    UINT64 vaOut;
} DEVICESTREAMCONNECTION, *PDEVICESTREAMCONNECTION;

typedef struct
{
    int16 samples;
    int16 blockAlign;
    union
    {
        uint32 ptr32;
        uint64 ptr64;
    };
}BUFFERDESC, *PBUFFERDESC;

typedef struct
{
	uint32 notification;
    uint32 msg2;
	uint64 timestamp;
    BUFFERDESC out[2];
	BUFFERDESC in;
    DEVICESTREAMCONNECTION connection;
} DICE_STREAMIO_COMPLETION, *PDICE_STREAMIO_COMPLETION;



struct DICE_ASIO_INFO_PARAM
{
	int32		asioError;
	uint32		unused_pad_0;
	uint32		sampleRate;
	uint32		bufferSize;

	uint32		playbackLatency;
	uint32		recordLatency;
	uint32		numOutChannelsAvailable;
	uint32		numInChannelsAvailable;

	char		outputChannelNames[MAX_ASIO_SEQUENCES][kTCAT_DICE_CHANNELNAME];
	char		inputChannelNames[MAX_ASIO_SEQUENCES][kTCAT_DICE_CHANNELNAME];
};


struct DICE_ASIO_INIT_PARAM
{
	CLIENTHANDLE  asioClientId;
	int32		asioError;
	uint32		isSlaveClient;
	uint32		unused_pad_0;
#if 0
	union
	{
		uint32		hResetRequestEvent32;
		uint64		hResetRequestEvent64;
	};
	union
	{
		uint32		hResyncRequestEvent32;
		uint64		hResyncRequestEvent64;
	};
	union
	{
		uint32		hLatenciesChangedEvent32;
		uint64		hLatenciesChangedEvent64;
	};
	union
	{
		uint32		pSharedState32;
		uint64		pSharedState64;
	};
#endif
};


struct DICE_ASIO_ALLOC_PARAM
{
	CLIENTHANDLE  asioClientId;
	int32		asioError;
	uint32		asioBufferSize;
//	uint32		unused_pad_0;
// Add 8/8/14 wzd
#if 0
    uint32		totalChannels;

	union
	{
		uint32		pOutBuffers32[MAX_ASIO_SEQUENCES];
		uint64		pOutBuffers64[MAX_ASIO_SEQUENCES];
	};
	union
	{
		uint32		pInBuffers32[MAX_ASIO_SEQUENCES];
		uint64		pInBuffers64[MAX_ASIO_SEQUENCES];
	};
	uint32		outputBuffersRequiredMap_SequenceIndex[MAX_ASIO_SEQUENCES];
	uint32		inputBuffersRequiredMap_SequenceIndex[MAX_ASIO_SEQUENCES];
#endif
};


struct DICE_ASIO_COMMAND_PARAM
{
    CLIENTHANDLE  asioClientId;
	int32		asioError;
};

struct DICE_ASIO_REGISTER_REMOVAL_EVENT
{
    CLIENTHANDLE  asioClientId;
    UINT64		  event;
};


struct DICE_ASIO_GET_BUFFER_SIZE
{
	CLIENTHANDLE  asioClientId;
	int32		asioError;
	uint32		minBufferSize;
	uint32		maxBufferSize;
	uint32		preferredBufferSize;
	int32		granularity;
};


struct DICE_ASIO_SET_BUFFER_SIZE
{
	CLIENTHANDLE  asioClientId;
	int32		asioError;
	uint32		bufferSize;
};


struct DICE_ASIO_SET_SAMPLE_RATE
{
	CLIENTHANDLE  asioClientId;
	int32		asioError;
	uint32		sampleRate;
};


                                            //**************************************************************************************************


}  // namespace tcat



#endif  // __DiceDrvioctl__h_
