//
//  Device.h
//  pal
//
//  Created by Joe Noel on 07/10/2015.
//  Copyright (c) 2015 Focusrite Audio Engineering Ltd. All rights reserved.
//

#ifndef __pal__Device__
#define __pal__Device__

#include <iostream>
#include <map>
#include <vector>
#include <cstdint>

#if defined (_WIN32)
#if defined (PALBUILD)
#define DLLLINKAGE  __declspec(dllexport)
#else
#define DLLLINKAGE  __declspec(dllimport)
#endif
#else
#define DLLLINKAGE
#endif

namespace Pal
{
    /**
     DeviceDelegate class to be the point of contact for updates from the device
     
     Register the delegate using device->setDelegate(delegate)
     
     These notifications could come from any thread. As such, subsequent processing shouldn't be
     called from these notifications. Instead, a flag should be set that is picked up by the main
     application loop or equivalent.
     */
    class DLLLINKAGE DeviceDelegate
    {
    public:
        virtual ~DeviceDelegate() = default;
        
        enum FirmwareOperation
        {
            Erase,
            Program,
            Download,
            Crc,
        };
        
        // Called when the device has fully initialised
        virtual void mount() {}
        
        // Called when the device has received a heads up that it's going to be destroyed
        virtual void unmount() {}
        
        // Updates on the progress of any firmware operation
        virtual void firmwareProgress(uint32_t percent, FirmwareOperation operation) { (void)percent; (void)operation; }
        
        // Notifies that the sample rate has changed
        virtual void sampleRateChanged() {}
        
        // Notifies that the clock source has changed
        virtual void clockSourceChanged() {}
        
        // Notifies that the clock lock has changed
        virtual void clockLockChanged() {}

        // Notifies that the buffer size has changed (Windows only)
        virtual void bufferSizeChanged() {}
        
        // The device is sending a custom notification
        virtual void userDcpReceived(uint32_t notification) { (void)notification; }
    };
    
    /**
     User-facing Device class
     */
    class DLLLINKAGE Device
    {
    public:        
        virtual ~Device() = default;
        
        // This is the entry point to start listening to updates from the device
        // This can be nullptr if you're no longer interested in updates
        virtual void        setDelegate(DeviceDelegate* delegate) = 0;
        
        virtual bool        supportsDcpCategory(uint16_t categoryId) const = 0;
        virtual void        resetDevice() = 0;
        virtual uint32_t    getFirmwareBuild() = 0;
        
        
        // -----
        // System info
        // -----
        
        virtual uint32_t    getProductId() const = 0;
        virtual uint32_t    getVendorId() const = 0;
        
        // -----
        // Sample Rate
        // -----
		virtual bool		canSampleRate(uint32_t sampleRate) = 0;
        virtual void        setSampleRate(uint32_t sampleRate) = 0;
        virtual uint32_t    getSampleRate() const = 0;
        
        // -----
        // Clock source
        // -----
        
        virtual void        setClockSource(uint32_t clockSource) = 0;
        virtual uint32_t    getClockSource() const = 0;
        virtual bool        isClockLocked() const = 0;
        
        // -----
        // Router
        // -----
        
        enum DCP_ROUTER_BUFFER
        {
            kBufferLow,
            kBufferMid,
            kBufferHigh,
        };
        
        virtual bool        routerIsSupported() const = 0;
        virtual uint32_t    numRoutes(DCP_ROUTER_BUFFER buffer) const = 0;
        virtual void        setRouter(DCP_ROUTER_BUFFER mode, uint32_t firstIndex, uint32_t const *pRoutes, uint32_t numRoutes) = 0;
        virtual void        getRouter(DCP_ROUTER_BUFFER mode, uint32_t firstIndex, uint32_t *pRoutes, uint32_t numRoutes) = 0;
        
        // -----
        // Mixer
        // -----
        
        virtual bool        mixerIsSupported() const = 0;
        virtual uint32_t    numMixerOutputs() const = 0;
        virtual uint32_t    numMixerInputs() const = 0;
        virtual uint32_t    mixerBitResolution() const = 0;
        virtual bool        mixerIsSigned() const = 0;
        virtual uint32_t    mixerUnityGainCoeff() const = 0;
        virtual void        setMixerCoeffs(uint32_t inIdx, uint32_t outIdx, float *pCoeff, uint32_t numCoeff) = 0;
        virtual void        getMixerCoeffs(uint32_t inIdx, uint32_t outIdx, float *pCoeff, uint32_t numCoeff) = 0;
        
        // -----
        // Peaks
        // -----
        
        virtual bool        peakIsSupported() const = 0;
        virtual uint16_t    numPeaks() const = 0;
        virtual uint8_t     peakBitResolution() const = 0;
        virtual void        getPeaks(uint32_t firstIndex, uint32_t* peaks, uint32_t numPeaks, bool update = false) = 0;
        
        // -----
        // NVM
        // -----
        
        // Does the device support the DCP NVM protocol?
        virtual bool        isNvmSupported() const = 0;
        
        // Total size of the NVM flash
        virtual uint32_t    nvmSize() const = 0;
        
        // How many segments are in the flash?
        virtual uint32_t    numNvmSegments() const = 0;
        
        // Get the index of a segment by name
        // Returns UINT32_MAX if it can't be found
        virtual uint32_t    getSegmentIndex(const std::string& name) const = 0;
        
        // Get the name of a segment by index
        virtual std::string getSegmentName(uint32_t segmentIndex) const = 0;
        
        // Get the size of a segment by index
        virtual uint32_t    getSegmentSize(uint32_t segmentSize) = 0;
        
        // Erase an NVM segment
        virtual void        eraseNvmSegment(uint32_t segmentIndex) = 0;
        
        // Program an NVM segment
        // Returns the number of bytes programmed (?)
        virtual void        programNvmSegment(uint32_t segmentIndex, const unsigned char* data, uint32_t dataSize, bool bcrc32 = false) = 0;
        
        // Download an NVM segment
        // The buffer will be resized to the correct size
        // If a segment index isn't provided, the whole image will be downloaded
        // If the data size is not provided, the whole segment will be downloaded
        virtual uint32_t    downloadNvm(std::vector<unsigned char>& buffer, uint32_t segmentIndex = UINT32_MAX, uint32_t dataSize = 0) = 0;
        
        // Calculate the CRC32 over a segment
        virtual uint32_t    calculateNvmCrc32(uint32_t segmentIndex, uint32_t size) = 0;
        
        // -----
        // Custom DCP
        // -----
        
        // Send custom data
        virtual void        vendorDcpCommand(uint16_t opcodeCategory, uint16_t opcodeIndex, void const* pParam, size_t paramSize, void* pResponse, size_t* responseSize) = 0;
        
        // -----
        // General
        // -----
        
        virtual std::string         getSerialNumber() const = 0;

        // -----
        // Buffer Size
        // -----

        virtual uint32_t    getMinBufferSize() const = 0;
        virtual uint32_t    getMaxBufferSize() const = 0;
        virtual uint32_t    getBufferSize() const = 0;
        virtual void        setBufferSize(uint32_t newBufferSize) = 0;

    };
}

#endif /* defined(__pal__Device__) */
