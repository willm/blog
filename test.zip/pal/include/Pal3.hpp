//
//  Pal3.hpp
//  dicetool
//
//  Created by Joe Noel on 14/01/2016.
//  Copyright © 2016 Focusrite Audio Engineering Ltd. All rights reserved.
//

#ifndef Pal3_hpp
#define Pal3_hpp

#include "Pal3_System.h"
#include "Pal3_Device.h"

#endif /* Pal3_hpp */
