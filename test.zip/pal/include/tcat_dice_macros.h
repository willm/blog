//==============================================================================
//####TCAT-SOURCE-HEADER-BEGIN####
//
// This confidential and proprietary source may be used only as authorized
// by a licensing agreement from TC Applied Technologies.
//
// Copyright (c) 2004-2014 TC Applied Technologies
//                         a division of TC Group Americas Ltd.
//                         All rights reserved.
//
// Unauthorized use, duplication or distribution of this source is strictly
// prohibited by law.
//
// The entire notice above must be reproduced on all authorized copies and
// copies may only be made to the extent permitted by a licensing agreement
// from TC Applied Technologies.
//
//####TCAT-SOURCE-HEADER-END####
//==============================================================================

#ifndef _TCAT_DICE_MACROS_H_
#define _TCAT_DICE_MACROS_H_


///////////////////////////////////////////////////////////////////////////////
//
//	stringify/concatenation macros
//
///////////////////////////////////////////////////////////////////////////////
//
#define __TCAT_STRINGIFY(x)					#x
#define __TCAT_LSTRINGIFY(x)				L#x
#define __TCAT_CAT_VERSION(mj,mn,s,b)		mj##.##mn##.##s##.##b
#define __TCAT_CAT_VERSION_SHORT(mj,mn,s)	mj##.##mn##.##s
#define __TCAT_CAT_UTI(x,y)					x##_##y
#define __TCAT_CAT(x,y)						x##y
#define __TCAT_CONJ(x,y)					x##,##y

#define TCAT_STRINGIFY(x)					__TCAT_STRINGIFY(x)
#define TCAT_LSTRINGIFY(x)					__TCAT_LSTRINGIFY(x)
#define TCAT_CAT_VERSION(mj,mn,s,b)			__TCAT_CAT_VERSION(mj,mn,s,b)
#define TCAT_CAT_VERSION_SHORT(mj,mn,s)		__TCAT_CAT_VERSION_SHORT(mj,mn,s)
#define TCAT_CAT_UTI(x,y)					__TCAT_CAT_UTI(x,y)
#define TCAT_CAT(x,y)						__TCAT_CAT(x,y)
#define TCAT_CONJ(x,y)						__TCAT_CONJ(x,y)



///////////////////////////////////////////////////////////////////////////////
//
//	version defines
//
///////////////////////////////////////////////////////////////////////////////

#define kTCAT_DICE_USR_PROVIDER_STR				TCAT_STRINGIFY	(kTCAT_DICE_PROVIDER)
#define kTCAT_DICE_USR_COPYRIGHT_STR			TCAT_STRINGIFY	(kTCAT_DICE_COPYRIGHT)

//	32-bit version format
//
//		0xFMmsbbbb
//		  F			Flags	- build flags indicating type and origin of binary
//		  1M		Major	- cosmetic number PM decides 
//			m		minor	- increase at interface change
//			 s		sub		- increase at release for bug fix, feature change, w/o interface change
//			  bbbb	build	- reflecting SVN revision
//
#define kTCAT_DICE_VERSION_MASK_COMPATIBILITY	0x3ff00000
#define kTCAT_DICE_VERSION_MASK_MAJOR			0x1f000000
#define kTCAT_DICE_VERSION_MASK_MINOR			0x00f00000
#define kTCAT_DICE_VERSION_MASK_SUB				0x000f0000
#define kTCAT_DICE_VERSION_MASK_BUILD			0x0000ffff
#define kTCAT_DICE_VERSION_MASK_BUILDSERVER		0x80000000
#define kTCAT_DICE_VERSION_MASK_INSTRUMENTED	0x40000000
#define kTCAT_DICE_VERSION_MASK_BETA			0x20000000	// included in compatibility bitmask

#define TCAT_VERSION32_MAJOR(v32)		(((v32)&kTCAT_DICE_VERSION_MASK_MAJOR)>>24)
#define TCAT_VERSION32_MINOR(v32)		(((v32)&kTCAT_DICE_VERSION_MASK_MINOR)>>20)
#define TCAT_VERSION32_SUB(v32)			(((v32)&kTCAT_DICE_VERSION_MASK_SUB)>>16)
#define TCAT_VERSION32_BUILD(v32)		((v32)&kTCAT_DICE_VERSION_MASK_BUILD)
#define TCAT_VERSION32(M,m,s,b)			(((M)<<24)|((m)<<20)|((s)<<16)|((b)))

#if kTCAT_DICE_VERSION_BUILDSERVER
#define kTCAT_DICE_VERSION_BLDSRVR_BIT	kTCAT_DICE_VERSION_MASK_BUILDSERVER
#else
#define kTCAT_DICE_VERSION_BLDSRVR_BIT	0
#endif

#ifdef _DEBUG
#define kTCAT_DICE_VERSION_INSTR_BIT	kTCAT_DICE_VERSION_MASK_INSTRUMENTED
#else
#define kTCAT_DICE_VERSION_INSTR_BIT	0
#endif//TCAT_DEBUG

#if kTCAT_DICE_VERSION_BETA
#define kTCAT_DICE_VERSION_BETA_BIT		kTCAT_DICE_VERSION_MASK_BETA
#else
#define kTCAT_DICE_VERSION_BETA_BIT		0
#endif

#define kTCAT_DICE_VERSION32			(TCAT_VERSION32(kTCAT_DICE_VERSION_MAJOR,kTCAT_DICE_VERSION_MINOR,kTCAT_DICE_VERSION_SUB,kTCAT_DICE_VERSION_BUILD) | kTCAT_DICE_VERSION_BLDSRVR_BIT | kTCAT_DICE_VERSION_INSTR_BIT | kTCAT_DICE_VERSION_BETA_BIT)

//	64-bit version format
//
//		0xFFMmmsssbbbbbbbb
//		  FF					Flags	- build flags indicating type and origin of binary
//		    M					Major	- major version number
//		     mm					minor	- increase at interface change
//		       sss				sub		- increase at release for bug fix, feature change, w/o interface change
//		          bbbbbbbb		build	- reflecting SCM revision
//
#define kTCAT_VERSION64_MASK_BUILDSERVER	0x8000000000000000ULL
#define kTCAT_VERSION64_MASK_DEBUG			0x4000000000000000ULL
#define kTCAT_VERSION64_MASK_BETA			0x2000000000000000ULL
#define kTCAT_VERSION64_MASK_FLAGS			0xff00000000000000ULL
#define kTCAT_VERSION64_MASK_MAJOR			0x00f0000000000000ULL
#define kTCAT_VERSION64_MASK_MINOR			0x000ff00000000000ULL
#define kTCAT_VERSION64_MASK_SUB			0x00000fff00000000ULL
#define kTCAT_VERSION64_MASK_BUILD			0x00000000ffffffffULL

#define TCAT_VERSION64_FLAGS(v64)		(((v64) & kTCAT_VERSION64_MASK_FLAGS) >> 56)
#define TCAT_VERSION64_MAJOR(v64)		(((v64) & kTCAT_VERSION64_MASK_MAJOR) >> 52)
#define TCAT_VERSION64_MINOR(v64)		(((v64) & kTCAT_VERSION64_MASK_MINOR) >> 44)
#define TCAT_VERSION64_SUB(v64)			(((v64) & kTCAT_VERSION64_MASK_SUB  ) >> 32)
#define TCAT_VERSION64_BUILD(v64)		( (v64) & kTCAT_VERSION64_MASK_BUILD)

#define TCAT_VERSION64(M,m,s,b)			(   (((uint64)(M) << 52) & kTCAT_VERSION64_MASK_MAJOR)  \
										  | (((uint64)(m) << 44) & kTCAT_VERSION64_MASK_MINOR)  \
										  | (((uint64)(s) << 32) & kTCAT_VERSION64_MASK_SUB  )  \
										  | ( (uint64)(b)        & kTCAT_VERSION64_MASK_BUILD)  \
										)


#if kTCAT_DICE_VERSION_BUILDSERVER
#define kTCAT_VERSION64_BLDSRVR_BIT		kTCAT_VERSION64_MASK_BUILDSERVER
#else
#define kTCAT_VERSION64_BLDSRVR_BIT		0
#endif

#ifdef _DEBUG
#define kTCAT_VERSION64_INSTR_BIT		kTCAT_VERSION64_MASK_DEBUG
#else
#define kTCAT_VERSION64_INSTR_BIT		0
#endif

#if kTCAT_DICE_VERSION_BETA
#define kTCAT_VERSION64_BETA_BIT		kTCAT_VERSION64_MASK_BETA
#else
#define kTCAT_VERSION64_BETA_BIT		0
#endif

#define kTCAT_DICE_VERSION64			(TCAT_VERSION64(kTCAT_DICE_VERSION_MAJOR,kTCAT_DICE_VERSION_MINOR,kTCAT_DICE_VERSION_SUB,kTCAT_DICE_VERSION_BUILD) | kTCAT_VERSION64_BLDSRVR_BIT | kTCAT_VERSION64_INSTR_BIT | kTCAT_VERSION64_BETA_BIT)

// version strings

#define kTCAT_DICE_VERSION				TCAT_CAT_VERSION(kTCAT_DICE_VERSION_MAJOR,kTCAT_DICE_VERSION_MINOR,kTCAT_DICE_VERSION_SUB,kTCAT_DICE_VERSION_BUILD)

#if kTCAT_DICE_VERSION_BUILDSERVER
#define kTCAT_DICE_VERSION_PRE1			kTCAT_DICE_VERSION
#else
#define kTCAT_DICE_VERSION_PRE1			kTCAT_DICE_VERSION local
#endif //kTCAT_DICE_VERSION_BUILDSERVER
#if kTCAT_DICE_VERSION_BETA
#define kTCAT_DICE_VERSION_PRE2			kTCAT_DICE_VERSION_PRE1 beta
#else
#define kTCAT_DICE_VERSION_PRE2			kTCAT_DICE_VERSION_PRE1
#endif //kTCAT_DICE_VERSION_BETA
#ifdef _DEBUG
#define kTCAT_DICE_VERSION_EXTENDED		kTCAT_DICE_VERSION_PRE2 debug
#else
#define kTCAT_DICE_VERSION_EXTENDED		kTCAT_DICE_VERSION_PRE2
#endif //_DEBUG

#define kTCAT_DICE_VERSION_STR			TCAT_STRINGIFY(kTCAT_DICE_VERSION)
#define kTCAT_DICE_VERSION_LSTR			TCAT_LSTRINGIFY(kTCAT_DICE_VERSION)
#define kTCAT_DICE_VERSION_EXTENDED_STR	TCAT_STRINGIFY(kTCAT_DICE_VERSION_EXTENDED)
#define kTCAT_DICE_VERSION_SHORT		TCAT_CAT_VERSION_SHORT(kTCAT_DICE_VERSION_MAJOR,kTCAT_DICE_VERSION_MINOR,kTCAT_DICE_VERSION_SUB)
#define kTCAT_DICE_VERSION_RC			kTCAT_DICE_VERSION_MAJOR,kTCAT_DICE_VERSION_MINOR,kTCAT_DICE_VERSION_SUB,kTCAT_DICE_VERSION_BUILD


///////////////////////////////////////////////////////////////////////////////

// Add macro to "personalize" the main GUID for the driver for ASIO and iface
#define TCAT_MAKE_ASIO_GUID(_g_)       { _g_.Data2^=0x1111; _g_.Data3 ^= 0x2222; }
#define TCAT_MAKE_IFACE_GUID(_g_)	   { _g_.Data2 &= 0x0f0f; _g_.Data3 &= 0xf0f0; }

#endif  //_TCAT_DICE_MACROS_H_
