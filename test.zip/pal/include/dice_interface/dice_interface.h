#ifndef DICE_INTERFACE_H
#define DICE_INTERFACE_H

#include "tcat.h"
#include "dcp_opcodes.h"
#include <string.h>		// for size_t
#ifndef uint8_t
typedef unsigned char      uint8_t;
#endif
using namespace tcat;
#pragma warning( push )
#pragma warning( disable: 4200 )
#include "Firmware/RedPre/src/eapAppSpace.h"
#include "Firmware/RedPre/src/ffDCP.h"
#pragma warning( pop )

enum
{
    eScarlettUSB = 0x1235
};

namespace tcat
{

#define kMaxNumSampleRates			16
#define kMaxNumClockSources			16
#define kMaxClockSourceNameLen		32
#define kMaxNumPlayChannels         64
#define kMaxNumRecordChannels       64
#define kMaxChannelNameLen          32

#define kName_Product               1   // Borowed from DiceIII SDK
#define kMaxProductName             (64)

class DiceInterface
{
public:
						DiceInterface();
	virtual				~DiceInterface();

	virtual bool		Initialize();
	virtual bool		CacheState();

// pure virtuals
public:
	virtual	bool		StartStreaming() = 0;
	virtual	bool		StopStreaming() = 0;
	virtual	bool		IsStreaming() = 0;

private:
	virtual uint32		sendDcpCommand( uint16 opcodeCategory, uint16 opcodeIndex,
										const void *data, size_t dataSize,
										void *response, size_t *responseSize ) = 0;
	virtual uint32		getDcpMaxTranserSize() = 0;

// interface
public:
	// system
	virtual uint32		GetVendorOUI();
	virtual uint32		GetProductID();
	virtual uint32		GetSerialNumber();
	virtual uint64		GetDiceSDKVersion64();
	virtual uint64		GetAppVersion64();

	// clock state
	virtual	uint32		GetClockSourceID();
	virtual	uint32		GetSampleRate();
	virtual	bool		SetClock( uint32 sampleRate, uint16 clockSourceID );

	// clock source list
	virtual	uint32		GetNumClockSources();
	virtual	bool		GetClockSource( uint32 index, uint16& sourceID, char *name = 0, uint32 nameSize = 0 );
	virtual	bool		GetClockSourceName( uint16 sourceID, char *name, uint32 nameSize );
	virtual	uint16		GetDefaultClockSourceID();

	// sample rate list
	virtual	uint32		GetNumSampleRates();
	virtual	bool		GetSampleRate( uint32 index, uint32& rate );

	// audio configuration
	virtual uint32		GetSortID();
	virtual uint32		GetNumRecordChannels( uint32 atSampleRate );
	virtual uint32		GetNumPlayChannels( uint32 atSampleRate );
	virtual	uint32		GetPlayLatency( uint32 atSampleRate );
	virtual	uint32		GetRecordLatency( uint32 atSampleRate );
    
    // channel names
    virtual bool        GetPlayChannelName( uint16 index, char* name, uint32 nameSize );
    virtual bool        GetRecordChannelName( uint16 index, char* name, uint32 nameSize );
	// DCP
	virtual uint32		SendDcpCommand( uint16 opcodeCategory, uint16 opcodeIndex,
										const void *data, size_t dataSize,
										void *response, size_t *responseSize );

	virtual void		ProcessDcpNotification( uint32 notificationFlags );
    virtual const char *GetProductName();
    virtual bool      GetMidiCaps(DD2_MIDI_CAPS* pCaps);
    
protected:
    virtual const DEVICE_PARAMS* getDeviceParams();

// internals
private:
	bool				getName( uint16 nameIndex, char *dest, uint32 destSize );
	bool				cacheSystemInfo();
	bool				cacheClockSourceState();
	bool				cacheClockSourceList();
	bool				cacheSampleRateList();
	bool				cacheAudioConfig();
	bool				cacheMidiConfig();
    bool                cacheChannelNames();

    bool                cacheDevParams();

// data
private:
	// system
	DCP_SYSTEM_INFO			mSystemInfo;

	// clock
	DCP_CLOCK_GET			mClockGet;
	uint32					mNumSampleRates;
	uint32					mSampleRates[kMaxNumSampleRates];
	uint32					mNumClockSources;
	DD2_CLOCK_SOURCE_ENTRY	mClockSources[kMaxNumClockSources];
	char					mClockSourceNames[kMaxNumClockSources][kMaxClockSourceNameLen];
    char                    mPlayChannelNames[kMaxNumPlayChannels][kMaxChannelNameLen];
    char                    mRecordChannelNames[kMaxNumPlayChannels][kMaxChannelNameLen];

	// audio
	DCP_AUDIO_GLOBAL		mAudioGlobal;
	DD2_AUDIO_CONFIG		mAudioConfigs[kRate_NumRates];

    // user
    DEVICE_PARAMS           mDevParams;
    char                    mCachedProductName[kMaxProductName];
};



//------------------------------------------------------------------------------

inline uint32 DiceInterface::GetVendorOUI()				{ return mSystemInfo.vendorOUI; }
inline uint32 DiceInterface::GetProductID()				{ return mSystemInfo.productID; }
inline uint32 DiceInterface::GetSerialNumber()			{ return mSystemInfo.serial; }
inline uint64 DiceInterface::GetDiceSDKVersion64()		{ return mSystemInfo.diceSDKVersion64; }
inline uint64 DiceInterface::GetAppVersion64()			{ return mSystemInfo.appVersion64; }


inline uint32 DiceInterface::GetSampleRate()			{ return mClockGet.sampleRate; }
inline uint32 DiceInterface::GetClockSourceID()			{ return mClockGet.sourceId; }

inline uint32 DiceInterface::GetNumClockSources()		{ return mNumClockSources; }
inline uint16 DiceInterface::GetDefaultClockSourceID()	{ return mClockSources[0].id; }	// index 0 is the device's default

inline uint32 DiceInterface::GetNumSampleRates()		{ return mNumSampleRates; }

inline uint32 DiceInterface::GetSortID()				{ return mAudioGlobal.sortID; }

inline const char *DiceInterface::GetProductName()                     { return mCachedProductName; }
inline const DEVICE_PARAMS* DiceInterface::getDeviceParams()           { return &mDevParams; }


} // namespace tcat
#endif
