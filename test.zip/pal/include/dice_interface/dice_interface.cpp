
//#include <string.h>
#include "../UniTracing.h"
#ifdef _WIN32
#include <ntddk.h>
#include "dice_interface.tmh"
#endif
//#define eDevice16ADDA	(5) // Borrowed from red16adda firmware - eapAppspace.h
using namespace tcat;

#include "dice_interface.h"

namespace tcat
{


DiceInterface::DiceInterface()
{
    memset(mPlayChannelNames, 0, sizeof(mPlayChannelNames));
    memset(mRecordChannelNames, 0, sizeof(mRecordChannelNames));
    memset(mCachedProductName, 0, sizeof(mCachedProductName));



	// empty
}



DiceInterface::~DiceInterface()
{
	// empty
}



bool DiceInterface::Initialize()
{
	return CacheState();
}



void DiceInterface::ProcessDcpNotification(uint32 notificationFlags)
{
    if (notificationFlags & DCP_NOTIFY_CLOCK_UPD)
    {
        TraceInfo(TRACEFLG_TDL,"**Clock Update interrupt");
        cacheClockSourceState();
        cacheClockSourceList();
        cacheSampleRateList();
    }

    if (notificationFlags & DCP_NOTIFY_CLOCK_LOCK)
    {
        TraceInfo(TRACEFLG_TDL,"**Clock Lock interrupt");
        cacheClockSourceState();
        cacheChannelNames();
    }

    if (notificationFlags & DCP_NOTIFY_AUDIO_UPD)
    {
        TraceInfo(TRACEFLG_TDL,"**Audio Update interrupt");
        cacheAudioConfig();
    }

    if (notificationFlags & DCP_NOTIFY_MIDI_UPD)
    {
        TraceInfo(TRACEFLG_TDL,"**MIDI Update interrupt");
        cacheMidiConfig();
    }
}



bool DiceInterface::CacheState()
{
	cacheSystemInfo();
	cacheClockSourceState();
	cacheClockSourceList();
	cacheSampleRateList();
	cacheAudioConfig();
	cacheMidiConfig();
    cacheChannelNames();
    cacheDevParams();
	return true;	
}



bool DiceInterface::SetClock( uint32 sampleRate, uint16 clockSourceID )
{
	uint32		dcpStatus;
	bool		retVal = false;

    TraceInfo(TRACEFLG_TDL,"DiceInterface::SetClock(sr:%d, clk:%d)", sampleRate, clockSourceID);
    if ((sampleRate != mClockGet.sampleRate) || (clockSourceID != mClockGet.sourceId))
	{
		DCP_CLOCK_SET	setCmd;

		setCmd.sampleRate = sampleRate;
		setCmd.sourceId = clockSourceID;
		setCmd.reserved = 0;

		dcpStatus = SendDcpCommand( DCP_CLASS_CLOCK, DCP_CLOCK_OP_SET, &setCmd, sizeof(setCmd), NULL, 0 );
		if (dcpStatus == kDcpRsp_success)
		{
			// FIXME -- set here or wait for clock interrupt (which would come much later)?
			mClockGet.sampleRate = sampleRate;
			mClockGet.sourceId = clockSourceID;
			retVal = true;
		}
		else
		{
			TraceError("DCP_CLOCK_OP_SET returned status %d", dcpStatus);
		}
	}
	else
	{
		TraceInfo(TRACEFLG_TDL,"already set to sample rate %d and clockSourceID %d", sampleRate, clockSourceID);
        retVal = true;
    }

	return retVal;
}



bool DiceInterface::GetClockSource( uint32 index, uint16& sourceID, char *name, uint32 nameSize )
{
	if (index >= mNumClockSources)
	{
		return false;
	}

	sourceID = mClockSources[index].id;

	if ((name != NULL) && (nameSize != 0))
	{
		size_t	maxSize = (nameSize > kMaxClockSourceNameLen) ? kMaxClockSourceNameLen : nameSize;
		memcpy( name, mClockSourceNames[index], maxSize );
		name[nameSize-1] = '\0';	// make sure it is null-terminated
	}

	return true;
}



bool DiceInterface::GetClockSourceName( uint16 sourceID, char *name, uint32 nameSize )
{
	bool	retVal = false;

	if ((name != NULL) && (nameSize != 0))
	{
		for (uint32 n = 0; n < mNumClockSources; n++)
		{
			DD2_CLOCK_SOURCE_ENTRY	*entry = &mClockSources[n];

			if (entry->id == sourceID)
			{
				size_t	maxSize = (nameSize > kMaxClockSourceNameLen) ? kMaxClockSourceNameLen : nameSize;
				memcpy( name, mClockSourceNames[n], maxSize );
				name[nameSize-1] = '\0';	// make sure it is null-terminated
				retVal = true;
				break;
			}
		}
	}

	return retVal;
}



bool DiceInterface::GetSampleRate( uint32 index, uint32& rate )
{
	if (index >= mNumSampleRates)
	{
		return false;
	}

	rate = mSampleRates[index];
	return true;
}



static uint8 getRateEnum( uint32 sampleRate )
{
	if (sampleRate >= 100000)
	{
		return kRate_High;
	}
	else if (sampleRate >= 50000)
	{
		return kRate_Mid;
	}
	return kRate_Low;
}



uint32 DiceInterface::GetNumPlayChannels( uint32 atSampleRate )
{
	return mAudioConfigs[getRateEnum(atSampleRate)].numPlayChannels;
}



uint32 DiceInterface::GetNumRecordChannels( uint32 atSampleRate )
{
	return mAudioConfigs[getRateEnum(atSampleRate)].numRecordChannels;
}



uint32 DiceInterface::GetPlayLatency( uint32 atSampleRate )
{
	return mAudioConfigs[getRateEnum(atSampleRate)].playLatency;
}



uint32 DiceInterface::GetRecordLatency( uint32 atSampleRate )
{
	return mAudioConfigs[getRateEnum(atSampleRate)].recordLatency;
}

    
bool DiceInterface::GetPlayChannelName( uint16 index, char* name, uint32 nameSize )
{
    bool	retVal = false;
    
    if ((name != NULL) && (nameSize != 0) && index < kMaxNumPlayChannels)
    {
        size_t	maxSize = (nameSize > kMaxChannelNameLen) ? kMaxChannelNameLen : nameSize;
        memcpy( name, mPlayChannelNames[index], maxSize );
        name[nameSize-1] = '\0';	// make sure it is null-terminated
        retVal = true;
    }
    
    return retVal;
}

bool DiceInterface::GetRecordChannelName( uint16 index, char* name, uint32 nameSize )
{
    bool	retVal = false;
    
    if ((name != NULL) && (nameSize != 0) && index < kMaxNumRecordChannels)
    {
        size_t	maxSize = (nameSize > kMaxChannelNameLen) ? kMaxChannelNameLen : nameSize;
        memcpy( name, mRecordChannelNames[index], maxSize );
        name[nameSize-1] = '\0';	// make sure it is null-terminated
        retVal = true;
    }
    
    return retVal;
}


bool DiceInterface::getName( uint16 nameIndex, char *dest, uint32 destSize )
{
	size_t		responseSize = destSize;
	uint32		dcpStatus;
	bool		retVal = false;

	if (dest == NULL)
	{
		TraceError("getName dest is NULL");
		return false;
	}
	if (destSize == 0)
	{
		TraceError("getName destSize is 0");
		return false;
	}

	dest[0] = '\0';

	dcpStatus = SendDcpCommand( DCP_CLASS_NAME, DCP_NAME_OP_GET, &nameIndex, sizeof(nameIndex), dest, &responseSize );
	if (dcpStatus == kDcpRsp_success)
	{
		retVal = true;
	}
	else
	{
		TraceError("DCP_CLASS_NAME (nameIndex %d) returned status %d", nameIndex, dcpStatus);
		dest[0] = '\0';
	}

	return retVal;
}



bool DiceInterface::cacheSystemInfo()
{
	size_t		responseSize = sizeof(mSystemInfo);
	uint32		dcpStatus;
	bool		retVal = false;

	memset( &mSystemInfo, 0, sizeof(mSystemInfo) );

	dcpStatus = SendDcpCommand( DCP_CLASS_SYSTEM, DCP_SYSTEM_OP_INFO, NULL, 0, &mSystemInfo, &responseSize );
	if (dcpStatus == kDcpRsp_success)
	{
		TraceInfo(TRACEFLG_TDL,"    SDK version  0x%016llx", mSystemInfo.diceSDKVersion64);
		TraceInfo(TRACEFLG_TDL,"    app version  0x%016llx", mSystemInfo.appVersion64);
		TraceInfo(TRACEFLG_TDL,"     vendor OUI  0x%08x", mSystemInfo.vendorOUI);
		TraceInfo(TRACEFLG_TDL,"     product ID  0x%08x", mSystemInfo.productID);
		TraceInfo(TRACEFLG_TDL,"  serial number  0x%08x", mSystemInfo.serial);
		retVal = true;
	}
	else
	{
		TraceError("DCP_SYSTEM_OP_INFO returned status %d", dcpStatus);
	}

	return retVal;
}



bool DiceInterface::cacheClockSourceState()
{
	bool		retVal = true;

	// get the clock settings
	{
		size_t		responseSize = sizeof(mClockGet);
		uint32		dcpStatus;

		memset( &mClockGet, 0, sizeof(mClockGet) );

		dcpStatus = SendDcpCommand( DCP_CLASS_CLOCK, DCP_CLOCK_OP_GET, NULL, 0, &mClockGet, &responseSize );
		if (dcpStatus == kDcpRsp_success)
		{
            TraceInfo(TRACEFLG_TDL,"device clock sampleRate: %d", mClockGet.sampleRate);
            TraceInfo(TRACEFLG_TDL,"device clock sourceId: %d", mClockGet.sourceId);
            TraceInfo(TRACEFLG_TDL,"device clcok activeSourceId: %d", mClockGet.activeSourceId);
        }
		else
		{
			TraceError("DCP_CLOCK_OP_GET returned status %d", dcpStatus);
			retVal = true;
		}
	}

	return retVal;
}



bool DiceInterface::cacheClockSourceList()
{
	size_t		responseSize = sizeof(mClockSources);
	uint32		dcpStatus;
	bool		retVal = false;

	mNumClockSources = 0;
	memset( &mClockSources, 0, sizeof(mClockSources) );
	memset( &mClockSourceNames, 0, sizeof(mClockSourceNames) );

	dcpStatus = SendDcpCommand( DCP_CLASS_CLOCK, DCP_CLOCK_OP_SOURCES_GET, NULL, 0, &mClockSources, &responseSize );
	if (dcpStatus == kDcpRsp_success)
	{
		mNumClockSources = (uint32)(responseSize / sizeof(mClockSources[0]));
		TraceInfo(TRACEFLG_TDL,"device supports %d clock sources", mNumClockSources);
		for (uint32 n = 0; n < mNumClockSources; n++)
		{
			retVal = getName( mClockSources[n].nameIndex, mClockSourceNames[n], sizeof(mClockSourceNames[n]) );
			if (retVal == false)
				break;
		}
	}
	else
	{
		TraceError("DCP_CLOCK_OP_SOURCES_GET returned status %d", dcpStatus);
	}

	return retVal;
}



bool DiceInterface::cacheSampleRateList()
{
	size_t		responseSize = sizeof(mSampleRates);
	uint32		dcpStatus;
	bool		retVal = false;

	mNumSampleRates = 0;
	memset( &mSampleRates, 0, sizeof(mSampleRates) );

	dcpStatus = SendDcpCommand( DCP_CLASS_CLOCK, DCP_CLOCK_OP_RATES_GET, NULL, 0, &mSampleRates, &responseSize );
	if (dcpStatus == kDcpRsp_success)
	{
		mNumSampleRates = (uint32)(responseSize / sizeof(uint32));
		TraceInfo(TRACEFLG_TDL,"device supports %d sample rates", mNumSampleRates);
		retVal = true;
	}
	else
	{
		TraceError("DCP_CLOCK_OP_RATES_GET returned status %d", dcpStatus);
	}

	return retVal;
}



bool DiceInterface::cacheAudioConfig()
{
	bool		retVal = false;

	{
		size_t		responseSize = sizeof(mAudioGlobal);
		uint32		dcpStatus;

		memset( &mAudioGlobal, 0, sizeof(mAudioGlobal) );

		dcpStatus = SendDcpCommand( DCP_CLASS_AUDIO, DCP_AUDIO_OP_GLOBAL, NULL, 0, &mAudioGlobal, &responseSize );
		if (dcpStatus == kDcpRsp_success)
		{
			TraceInfo(TRACEFLG_TDL,"device sortID %d", mAudioGlobal.sortID);
			retVal = true;
		}
		else
		{
			TraceError("DCP_AUDIO_OP_GLOBAL returned status %d", dcpStatus);
		}
	}

	{
		memset( &mAudioConfigs, 0, sizeof(mAudioConfigs) );

		for (uint8 rate = 0; rate < kRate_NumRates; rate++)
		{
			DD2_AUDIO_CONFIG	*config = &mAudioConfigs[rate];
			size_t				responseSize = sizeof(*config);
			uint32				dcpStatus;

			TraceInfo(TRACEFLG_TDL,"requesting audioconfig for rate %d", rate);
			dcpStatus = SendDcpCommand( DCP_CLASS_AUDIO, DCP_AUDIO_OP_CONFIG_GET, &rate, sizeof(rate), config, &responseSize );
			if (dcpStatus == kDcpRsp_success)
			{
                TraceInfo(TRACEFLG_TDL,"  playChan %d, recChan %d, playLatency %d, recLatency %d",
						   config->numPlayChannels, config->numRecordChannels, config->playLatency, config->recordLatency );
				retVal = true;
			}
			else
			{
				TraceError("DCP_AUDIO_OP_CONFIG_GET returned status %d", dcpStatus);
			}
		}
	}

	return retVal;
}



bool DiceInterface::cacheMidiConfig()
{
	bool		retVal = false;

	// FIXME -- not implemented yet

	return retVal;
}

bool DiceInterface::cacheDevParams()
{
    DCP_USER_GET_ID getCommand = { 0 };
//	size_t responseSize = sizeof(mDevParams);
	size_t responseSize = 12;// 3 * sizeof(uint32);
	// Only really need the first 2 words of this struct but must request at least 3.
    memset(&mDevParams, 0, sizeof(mDevParams));
    getCommand.idx = 0;
    getCommand.size = (uint32)responseSize;

    char tempBuf[kMaxProductName];
    const char *tempString = "Unknown device";



#pragma warning(disable:4459) 

    uint32 dcpStatus = sendDcpCommand(DCP_CLASS_USER, DCP_USER_OP_GET_ID_BLK, &getCommand, sizeof(getCommand), &mDevParams, &responseSize); // Use RAW command without flush and retry logic
    if (dcpStatus == kDcpRsp_success)
    {
        switch (mDevParams.deviceRange)
        {
            case eClarett:
            {
                switch (mDevParams.unitType)
                {
                    case eDevice8Pre:      tempString = "Clarett 8Pre";     break;
                    case eDevice8PreX:     tempString = "Clarett 8PreX";    break;
                    case eDevice4Pre:      tempString = "Clarett 4Pre";     break;
                    case eDevice2Pre:      tempString = "Clarett 2Pre";     break;
                    default:
                        TraceError("Unknown eClarett[%d]", mDevParams.unitType);
                        break;
                }
            }
            break;

            case eRedPre:
			{
				switch (mDevParams.unitType)
				{
					case eDevice8Pre:      tempString = "Red 8Pre";     break;
					case eDevice4Pre:      tempString = "Red 4Pre";     break;
					case eDevice16ADDA:      tempString = "Red 16Line";     break;
					case eDevice8Line:      tempString = "Red 8Line";		break;
					default:
						TraceError("Unknown eRedPre[%d]", mDevParams.unitType);
						break;
				}
			}
            break;

            case eScarlettUSB:
            {
				TraceInfo(TRACEFLG_TDL,"getName:  pDevParams->ignoreHardware = %d", mDevParams.ignoreHardware);
                if (getName(static_cast<uint16>(mDevParams.unitOption1), tempBuf, sizeof(tempBuf)))
                {
                    tempString = tempBuf;
                }
            }
            break;

        }
    }
	else
	{
		TraceError("cacheDevParams(): sendDcpCommand(DCP_CLASS_USER, DCP_USER_OP_GET_ID_BLK failed (%d)", dcpStatus);
	}

    strncpy(mCachedProductName,tempString, kMaxProductName);
    //    return (dcpStatus == kDcpRsp_success);
    return (kDcpRsp_success);
}

bool DiceInterface::cacheChannelNames()
{
    bool retVal = true;
    
    uint8 band = static_cast<uint16>(getRateEnum(GetSampleRate()));
    // Play channels
    {
        // Wipe out the channel names
        memset(mPlayChannelNames, 0, sizeof(mPlayChannelNames));
        
        // Prepare the request
        DCP_AUDIO_CHANS_GET_IN channelRequest;
        memset(&channelRequest, 0, sizeof(channelRequest));
//        channelRequest.rate = kRate_Low /*getRateEnum(GetSampleRate())*/; // Assume the channels don't change from the low rate
        channelRequest.rate = band;            
        channelRequest.startIndex = 0;
        channelRequest.num = static_cast<uint16>(mAudioConfigs[band].numPlayChannels);
        
        // Prepare the response
        DD2_AUDIO_CHANNEL audioChannels[kMaxNumPlayChannels];
        size_t responseSize = channelRequest.num * sizeof(DD2_AUDIO_CHANNEL); // Only expect the channels that we're asking for
        
        // Get the channel info
        uint32 dcpStatus = SendDcpCommand(DCP_CLASS_AUDIO, DCP_AUDIO_OP_PLAY_CHANS_GET, &channelRequest, sizeof(channelRequest), &audioChannels, &responseSize);
        if (dcpStatus == kDcpRsp_success)
        {
            TraceInfo(TRACEFLG_TDL,"DiceInterface::cacheChannelNames: reading %d play channels", channelRequest.num);

            for (size_t i = 0; i < channelRequest.num; ++i)
            {
                uint16 nameIndex = audioChannels[i].nameIndex;
                if (!getName(nameIndex, mPlayChannelNames[i], sizeof(mPlayChannelNames[i])))
                    retVal = false;
            }
        }
        else
        {
            TraceError("DCP_AUDIO_OP_PLAY_CHANS_GET returned status %d", dcpStatus);
            retVal = false;
        }
    }
    
    // Record channels
    {
        // Wipe out the channel names
        memset(mRecordChannelNames, 0, sizeof(mRecordChannelNames));
        
        // Prepare the request
        DCP_AUDIO_CHANS_GET_IN channelRequest;
        memset(&channelRequest, 0, sizeof(channelRequest));
        channelRequest.rate = band;
        channelRequest.startIndex = 0;
        channelRequest.num = channelRequest.num = static_cast<uint16>(mAudioConfigs[band].numRecordChannels);
        
        // Prepare the response
        DD2_AUDIO_CHANNEL audioChannels[kMaxNumRecordChannels];
        size_t responseSize = channelRequest.num * sizeof(DD2_AUDIO_CHANNEL); // Only expect the channels that we're asking for
        
        // Get the channel info
        uint32 dcpStatus = SendDcpCommand(DCP_CLASS_AUDIO, DCP_AUDIO_OP_REC_CHANS_GET, &channelRequest, sizeof(channelRequest), &audioChannels, &responseSize);
        if (dcpStatus == kDcpRsp_success)
        {
            TraceInfo(TRACEFLG_TDL,"DiceInterface::cacheChannelNames: reading %d record channels", channelRequest.num);
            
            for (size_t i = 0; i < channelRequest.num; ++i)
            {
                uint16 nameIndex = audioChannels[i].nameIndex;
                if (!getName(nameIndex, mRecordChannelNames[i], sizeof(mRecordChannelNames[i])))
                    retVal = false;
            }
        }
        else
        {
            TraceError("DCP_AUDIO_OP_REC_CHANS_GET returned status %d", dcpStatus);
            retVal = false;
        }
    }
    
    return retVal;
}
    
    
uint32 DiceInterface::SendDcpCommand( uint16 opcodeCategory, uint16 opcodeIndex,
									  const void *data, size_t dataSize,
									  void *response, size_t *responseSize )
{
	uint32		dcpStatus;

	dcpStatus = sendDcpCommand( opcodeCategory, opcodeIndex, data, dataSize, response, responseSize );

	if (((dcpStatus == kDcpRsp_invalidCmdSequence) || (dcpStatus == kDcpRsp_invalidState)) && !((opcodeCategory == DCP_CLASS_SYSTEM) && (opcodeIndex == DCP_SYSTEM_OP_FLUSH)))
	{
		TraceWarning(TRACEFLG_TDL,"sendDcpCommand returned dcpStatus %d, sending flush opcode...", dcpStatus);

		// send the flush command
		sendDcpCommand( DCP_CLASS_SYSTEM, DCP_SYSTEM_OP_FLUSH, 0, 0, 0, 0 );

		// then try again
		dcpStatus = sendDcpCommand( opcodeCategory, opcodeIndex, data, dataSize, response, responseSize );
	}

	return dcpStatus;
}


bool DiceInterface::GetMidiCaps(DD2_MIDI_CAPS* pCaps)
{
    bool rv=true;
    pCaps->numInPorts = pCaps->numOutPorts = 0;

    switch (mDevParams.deviceRange)
    {
        case eRedPre:   // No MIDI here boss
            break;

        case eClarett:
        {
            switch (mDevParams.unitType)
            {
                case eDevice8Pre:
                case eDevice8PreX:
                case eDevice4Pre:
                case eDevice2Pre:
                {
                    size_t size = sizeof(DD2_MIDI_CAPS);
                    auto dcpStatus = sendDcpCommand(DCP_CLASS_MIDI, DCP_MIDI_OP_CAPS, NULL, 0, pCaps, &size);
                    rv = (dcpStatus == kDcpRsp_success);
                    break;
                }

                default:
                    TraceError("  unknown Clarett type:%d", mDevParams.unitType);
                    break;
            }

        }
        break;

        case eScarlettUSB:
        {
            size_t size = sizeof(DD2_MIDI_CAPS);
            auto dcpStatus = sendDcpCommand(DCP_CLASS_MIDI, DCP_MIDI_OP_CAPS, NULL, 0, pCaps, &size);
            rv = (dcpStatus == kDcpRsp_success);
        }
        break;

        default:
            TraceError("  Unknown Device Range:0x%x", mDevParams.deviceRange);
            rv = false;
            break;
    }

    return rv;
}

}
