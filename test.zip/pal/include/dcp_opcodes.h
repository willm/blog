//==============================================================================
//####TCAT-SOURCE-HEADER-BEGIN####
//
// This confidential and proprietary source may be used only as authorized
// by a licensing agreement from TC Applied Technologies.
//
// Copyright (c) 2014-2015 TC Applied Technologies
//                         a division of TC Group Americas Ltd.
//                         All rights reserved.
//
// Unauthorized use, duplication or distribution of this source is strictly
// prohibited by law.
//
// The entire notice above must be reproduced on all authorized copies and
// copies may only be made to the extent permitted by a licensing agreement
// from TC Applied Technologies.
//
//####TCAT-SOURCE-HEADER-END####
//==============================================================================

#ifndef _DCPOPCODES_H_
#define	_DCPOPCODES_H_

//#include "TCTypes.h"
//#include "platform.h"

#if defined(__cplusplus)
namespace tcat
{
extern "C" {
#endif


//**************************************************************************************************

typedef enum
{
	kDcpRsp_success,					// Returned by handlers in case of success
	kDcpRsp_error,						// Returned by handlers if no better choice
	kDcpRsp_timeOut,					// Returned by system only
	kDcpRsp_invalidCmdSequence,			// Returned by system only
	kDcpRsp_invalidOpcodeCategory,		// Returned by system only
	kDcpRsp_invalidState,				// Returned by system only
	kDcpRsp_maxTransferSizeExceeded,	// Returned by system only
	kDcpRsp_invalidOpcodeIndex,			// Returned by handlers if the index is not supported
	kDcpRsp_invalidArgument,			// Returned by handlers if arguments do not match

	// these are only returned by the driver
	kDcpRsp_dcpNotSupported,
	kDcpRsp_invalidRspSequence,
	kDcpRsp_deviceNotAttached,
	kDcpRsp_deviceSuspended,
	kDcpRsp_noMemory,
}DCP_RSP_CODE;


typedef enum
{
	eFSS_FLAG_BOOT		= (1<<0),
	eFSS_FLAG_APP		= (1<<1),
	eFSS_FLAG_APP_GOLD	= (1<<2),
	eFSS_FLAG_PROT		= (1<<3),
	eFSS_FLAG_LOCK		= (1<<4),
	eFSS_FLAG_SPS2		= (1<<5)
}FSS_FLAGS_ENUM;


typedef struct
{
	uint16		id;					// the unique identifier used to reference this clock source
	uint16		nameIndex;			// index for the clock source name
}DD2_CLOCK_SOURCE_ENTRY;

enum
{
	kRate_Low			= 0,
	kRate_Mid			= 1,
	kRate_High			= 2,
	kRate_NumRates
};

typedef struct
{
	uint16		numPlayChannels;	// total number of channels
	uint16		numRecordChannels;	// total number of channels
	uint32		playLatency;		// latency in samples
	uint32		recordLatency;		// latency in samples
	uint32		reserved[3];		// reserved - set to zero
}DD2_AUDIO_CONFIG;

enum
{
	kChanType_None				= 0,
	kChanType_Analog			= 1,
	kChanType_SPDIF				= 2,
	kChanType_AES				= 3,
	kChanType_ADAT				= 4,
	kChanType_TDIF				= 5,
	kChanType_MADI				= 6,
	kChanType_Special			= 7,
};

enum
{
	kChanFlag_TypeMask			= 0x1f,			// specifies a kChanType value
	kChanFlag_AC3Capable		= (1 << 14),	// is AC3 capable, only valid for output channels
	kChanFlag_Hidden			= (1 << 15),	// will not be published to OS audio, can be used for private driver extensions
};

enum
{
	kChanIndex_NotStreaming		= 0xff,			// if both busIndex and busSubIndex are set to this it indicates that the channel
												// should be presented to OS audio, but is not actually streamed
};

typedef struct
{
	uint8		busIndex;			// the isoch stream on a FireWire bus, the endpoint number on USB
	uint8		busSubIndex;		// the index of the muxed channel within the FireWire isoch stream or USB endpoint
	uint16		nameIndex;			// index for the full channel name (for OS compatibility the max length is 31 chars plus a null-terminator)
	uint16		shortNameIndex;		// index for an optional short channel name which applications can utilize, zero indicates none provided
	uint16		groupNameIndex;		// channels with the same index will be grouped, zero indicates no group
	uint32		latency;			// channel latency in samples
	uint16		flags;				// flags
	uint16		reserved;			// reserved - set to zero
}DD2_AUDIO_CHANNEL;

typedef struct
{
	uint16		numInPorts;			// total number of input ports
	uint16		numOutPorts;		// total number of output ports
}DD2_MIDI_CAPS;

enum
{
	kMidiFlag_IsPrivate		= (1 << 0),		// the port is not published, only supported on OS X
	kMidiFlag_IsEmbedded	= (1 << 1),		// not a connector but a virtual port, only supported on OS X
};

typedef struct
{
	uint8		busIndex;			// for FireWire the stream to use, for USB the endpoint number
	uint8		busSubIndex;		// for FireWire and USB the index of the muxed port within the stream or endpoint
	uint16		nameIndex;			// index for the MIDI port name
	uint16		maxSpeed;			// Bps, standard MIDI is 3125
	uint16		flags;				// flags
	uint32		reserved;			// reserved - set to zero
}DD2_MIDI_PORT;

//**************************************************************************************************



/***************************************************************************************************
 * This header file describes each of the DCP classes and their
 * opcodes. A total of 12 bits (4096) is reserved for classes.
 * This file only describes those managed by TCAT.
 * Vendor specific classes can be added from 2048 and up.
 *
 * Note: All data are in little endian format end to end.
 **************************************************************************************************/

#define DCP_CLASS_SYSTEM				0
#define DCP_CLASS_PEAK					1
#define DCP_CLASS_MIXER					2
#define DCP_CLASS_ROUTER				3
#define DCP_CLASS_NVM					4
#define DCP_CLASS_NAME					5
#define DCP_CLASS_CLOCK					6
#define DCP_CLASS_AUDIO					7
#define DCP_CLASS_MIDI					8


#define DCP_CLASS_PAL					1024
#define DCP_CLASS_WIN_DRIVER_PRIVATE	1025
#define DCP_CLASS_OSX_DRIVER_PRIVATE	1026


#define DCP_CATEGORY_VENDOR_MIN			2048
#define DCP_CATEGORY_VENDOR_MAX			4095


/***************************************************************************************************
 * DCP_CLASS_SYSTEM
 * System specific functions such as enquiring about classes
 **************************************************************************************************/

//--------------------------------------
// FLUSH command
// Only used my the link layer to synchronize communication
// Never called from a client
//--------------------------------------
#define DCP_SYSTEM_OP_FLUSH			0


//--------------------------------------
// ENQUIRE command
// Enquire for existence of a class
// Input:		uint16 containing class to enquire about
// Output:		uint8 returns 1 if class exist, 0 if it is not present
// Return code:	kDcpRsp_success
//--------------------------------------
#define DCP_SYSTEM_OP_ENQUIRE		1


//--------------------------------------
// INFO command
// Get Information on the version of the running firmware
// Input:		none
// Output:		DCP_SYSTEM_INFO
// Return code:	kDcpRsp_success
//--------------------------------------

#define DCP_SYSTEM_OP_INFO			2

typedef struct
{
	uint64		diceSDKVersion64;	// set to DICE_SDK_VERSION64, version of the DICE SDK this app was built with
	uint64		appVersion64;		// application version
	char		appBuildDate[16];	// application build date
	char		appBuildTime[16];	// application build time
	uint32		vendorOUI;			// vendor OUI
	uint32		productID;			// product ID
	uint8		reserved[16];		// reserved -- set to zero
	uint32		serial;				// serial number
	uint8		mac[6];				// mac address
}DCP_SYSTEM_INFO;


//--------------------------------------
// REBOOT command
// Reboot the application
// Input:		none
// Output:		none
// Return code:	kDcpRsp_success
//
// From the host perspective the device will disappear soon after this
// command and the response might not be received
//--------------------------------------
#define DCP_SYSTEM_OP_BOOT			3



/***************************************************************************************************
 * DCP_CLASS_PEAK
 * Handles reading of peak values from the router peak engine
 **************************************************************************************************/

//--------------------------------------
// CAPS command
// Enquire about the capabilities of the peak
// Input:		none
// Output:		DCP_PEAK_CAPS structure
// Return code:	kDcpRsp_success
//--------------------------------------
#define DCP_PEAK_OP_CAPS			0

typedef struct
{
	uint16		size;				// max number of peaks supported
	uint8		resolution;			// bits of resolution
	uint8		reserved;			// reserved - set to zero
}DCP_PEAK_CAPS;


//--------------------------------------
// GET command
// Get a number of peaks.
// Input:		DCP_PEAK_GET_IN
// Output:		array of uint32 with peak values
// Return code:	kDcpRsp_success, kDcpRsp_invalidArgument, kDcpRsp_maxTransferSizeExceeded
//--------------------------------------
#define DCP_PEAK_OP_GET				1

typedef enum
{
	kDcpPeakGetFlags_new = 0x00000001	// if set, a new measurement will be started after the GET call
}DCP_PEAK_GET_FLAGS;

typedef struct
{
	uint16		idx;				// first peak to get
	uint16		nb;					// number of peaks to get
	uint32		flags;
}DCP_PEAK_GET_IN;



/***************************************************************************************************
 * DCP_CLASS_MIXER
 * Handles setting and getting of mixer data
 **************************************************************************************************/

//--------------------------------------
// CAPS command
// Enquire about the capabilities of the mixer
// Input:		none
// Output:		DCP_MIXER_CAPS structure
// Return code:	kDcpRsp_success
//--------------------------------------
#define DCP_MIXER_OP_CAPS			0

typedef enum
{
	kDcpMixerCapsFlags_rd 	= 0x00000001,
	kDcpMixerCapsFlags_wr 	= 0x00000002,
	kDcpMixerCapsFlags_sign = 0x00000004,
}DCP_MIXER_CAPS_FLAGS;

typedef struct
{
	uint8		outputs;			// number of outputs
	uint8		inputs;				// number of inputs
	uint8		resolution;			// bits of resolution
	uint8		unity;				// unity gain bit (uinty gain is 1<<unity)
	uint32		flags;
}DCP_MIXER_CAPS;


//--------------------------------------
// GET command
// Get a number of mixer gains
// Input:		DCP_MIXER_GET_IN structure
// Output:		array of int16 coefficients
// Return code:	kDcpRsp_success, kDcpRsp_invalidArgument
//--------------------------------------
#define DCP_MIXER_OP_GET			1

typedef struct
{
	uint8		output;				// first output to get
	uint8		input;				// first input to get
	uint16		nb;					// number of gains to get
}DCP_MIXER_GET_IN;


//--------------------------------------
// SET command
// Set a number of mixer gains
// Input:		DCP_MIXER_SET_IN structure
// Output:		none
// Return code:	kDcpRsp_success, kDcpRsp_invalidArgument
//--------------------------------------
#define DCP_MIXER_OP_SET			2

typedef struct
{
	uint8		output;				// first output to get
	uint8		input;				// first input to get
//	int16		gains[];
}DCP_MIXER_SET_IN;


//--------------------------------------
// SAT command
// Get the saturation bits
// Input:		none
// Output:		array of uint32 to fit number of outputs
// Return code:	kDcpRsp_success
//--------------------------------------
#define DCP_MIXER_OP_SAT			3



/***************************************************************************************************
 * DCP_CLASS_ROUTER
 * Handles setting and getting of router data
 *
 * Note: In most system only one router is required for all rate
 *       modes. In some cases it is feasible to have a separate
 *       buffer for mid and high modes.
 *       The firmware will save space both in ram and persistent
 *       storage if it only has one buffer.
 *       If kDcpRouterCapsFlags_mid_buf is not defined the system
 *       will use the low buffer when in mid mode.
 *       If kDcpRouterCapsFlags_hi_buf is not defined the system
 *       will use the mid buffer if defined or the low buffer
 *       when in high mode.
 *
 **************************************************************************************************/

//--------------------------------------
// CAPS command
// Enquire about the capabilities of the router
// Input:		none
// Output:		DCP_ROUTER_CAPS structure
// Return code:	kDcpRsp_success
//--------------------------------------
#define DCP_ROUTER_OP_CAPS			0

typedef enum
{
	kDcpRouterCapsFlags_wr 			= 0x00000001,  //router is writeable
	kDcpRouterCapsFlags_mid_buf		= 0x00000002,  //mid rate has its own buffer
	kDcpRouterCapsFlags_hi_buf		= 0x00000004,  //hi rate has its own buffer
	kDcpRouterCapsFlags_meth_msk	= 0x000000f0,
	kDcpRouterCapsFlags_meth_A		= 0x00000000   //full router word method
}DCP_ROUTER_CAPS_FLAGS;

typedef struct
{
	uint16		size_low;			// number of routes in low pattern
	uint16		size_mid;			// number of routes in mid pattern
	uint16		size_hi;			// number of routes in hi  pattern
	uint16		format;				// 0 for the 5/7/5/7 router layout
	uint32		flags;
}DCP_ROUTER_CAPS;


//--------------------------------------
// GET command
// Get routes from the router
// Input:		DCP_ROUTER_GET_IN
// Output:		array of uint32 routes
// Return code:	kDcpRsp_success, kDcpRsp_invalidArgument
//--------------------------------------
#define DCP_ROUTER_OP_GET			1

typedef struct
{
	uint16		idx;				// starting index to get
	uint8		nb;					// number of routes to get
	uint8		buffer;				// 0-2 depends on capabilities
}DCP_ROUTER_GET_IN;

//The format of the routes is as follows:
//--------------------------------------
//|  0     |s_dev| s_ch  |d_dev| d_ch  |
//--------------------------------------
//   8       5      7      5      7
//
// s_dev:	source device, the host should know the sources and their assignments
// s_ch:	source channel
// d_dev:	destination device, the host should know the destinations and their assignments
// d_ch:	destination channel
//


//--------------------------------------
// SET command
// Set routes to the router
// Input:		DCP_ROUTER_SET_IN
// Output:		none
// Return code:	kDcpRsp_success, kDcpRsp_invalidArgument
//--------------------------------------
#define DCP_ROUTER_OP_SET			2

typedef struct
{
	uint16		idx;				// starting index to set
	uint8		buffer;				// 0-2 depends on capabilities
	uint8		reserved;			// reserved - set to zero
//	uint32		routes[];			//
}DCP_ROUTER_SET_IN;

//The format of the routes is as follows:
//--------------------------------------
//|  0     |s_dev| s_ch  |d_dev| d_ch  |
//--------------------------------------
//   8       5      7      5      7
//
// s_dev:	source device, the host should know the sources and their assignments
// s_ch:	source channel
// d_dev:	destination device, the host should know the destinations and their assignments
// d_ch:	destination channel
//



/***************************************************************************************************
 * DCP_CLASS_NVM
 * Handles updating NVM storage including firmware applications
 *
 * The firmware defines a fixed layout of the NVM. DCP provides
 * functionality to inspect the layout and to access each section
 * for reading and writing.
 * Each section might have headers and checksums but that is outside
 * the scope of this protocol as it is application specific.
 *
 * A function exist to return the crc32 of a block of data so the
 * host can verify against the programmed buffer.
 *
 * This system also supports a request for the complete NVM image.
 * This function is useful for obtaining production images.
 *
 * Programming happens on the fly in the DCP thread as programming
 * a buffer (max 1k) will take only a few ms for modern NVM devices.
 *
 * Erasing a segment can take seconds and it is an overlapped operation
 * which happens in a local thread.
 *
 * Safety against disruption:
 *   As mentioned above each sector depending on purpose will have
 *   mechanisms to deal with partial erase and programming situations
 *   resulting from disconnection or NVM device error. Here are some
 *   examples.
 *
 *	 DICE3 2ndary boot  The dice chip expects a header format and crc32
 *	 					If those are not correct the ROM boot will enter
 *	 					the UART boot loader.
 *	 					In the rare' case where the boot needs to be updated
 *	 					the host should do a complete crc32 of the programmed
 *	 					block and compare it against the file before the device
 *	 					is reset.
 *
 *
 *	 App./Golden App.	It is assumed that the boot sector will check for header
 *	 					and crc32, first for the App. and if it is not valid for
 *	 					the Golden App. As the golden App. is not expected to be
 *	 					updated in the field it should always be good.
 *	 					Disruption during App programming whether during erase or
 *	 					programming would in all likelihood (2^-32) result in an
 *	 					illegal	image (header and/or crc32).
 *
 *	 SPS2 block			The SPS2 system has its own security and if programming or
 *	 					erase is disrupted it will fall back to factory settings.
 *
 *	 STM32 Boot			This resides in the Processor Flash and is not accessible
 *	 					through this system. This boot sector will check the App.
 *	 					in NVM and see if it is valid. If not it will check the
 *	 					Golden App.
 *	 					It will then compare the obtained image information with the
 *	 					one programmed in internal flash. It the internal one is
 *	 					not the same it will update the internal image from the NVM.
 *
 *	 FPGA/ Golden FPGA	The app. will check if the corresponding FPGA image is good.
 *	 					If the NON Golden App. is loaded and the NON Golden FPGA is
 *	 					not valid the App. should erase the App. sector and reboot
 *	 					to make sure Golden App is running.
 *
 *	 Other sections		It is up to the implementor of these sections to assure that
 *	 					there is some kind of check which will prevent the system
 *	 					from hanging if the section contains illegal data.
 *
 **************************************************************************************************/

//--------------------------------------
// CAPS command
// Enquire about the capabilities of the NVM
// Input:		none
// Output:		DCP_ROUTER_CAPS structure
// Return code:	kDcpRsp_success
//--------------------------------------
#define DCP_NVM_OP_CAPS				0

typedef struct
{
	uint32		size;				// total number of bytes of the NVM
	uint32		nbSecments;			// number of segments
	uint16		prgTime;			// max ms/64kB programming time
	uint16		eraseTime;			// max ms/64kB erase time
	uint32		flags;
}DCP_NVM_CAPS;


//--------------------------------------
// INFO command
// Get info about a segment
// Input:		uint32 segment number
// Output:		DCP_NVM_INFO_OUT
// Return code:	kDcpRsp_success, kDcpRsp_invalidArgument
//--------------------------------------
#define DCP_NVM_OP_INFO				1

typedef struct
{
	uint32		size;				// size of segment in bytes
	uint32		flags;				// flags defined for block (FSS_FLAGS_ENUM, bit 0-15 reserved, 16-31 vendor specific)
	char		name[16];			// null-terminated name (max 15 chars)
}DCP_NVM_INFO_OUT;


//--------------------------------------
// ERASE command
// Start erasing a segment
// Input:		DCP_NVM_ERASE_IN
// Output:		none
// Return code:	kDcpRsp_success, kDcpRsp_invalidArgument, kDcpRsp_error
//--------------------------------------
#define DCP_NVM_OP_ERASE			2


//--------------------------------------
// POLL_STAT command
// Enquire status of erase or lock
// Input:		DCP_NVM_ERASE_IN
// Output:		uint8 progress 0-255, 255 is done
// Return code:	kDcpRsp_success, kDcpRsp_invalidArgument
//--------------------------------------
#define DCP_NVM_OP_POLL_STAT		3

typedef struct
{
	uint32		segment;			// segment to erase
	uint32		flags;				// for future expansion
}DCP_NVM_ERASE_IN;


//--------------------------------------
// PROGRAM command
// Program part of a section
// Input:		DCP_NVM_PROGRAM_IN
// Output:		none
// Return code:	kDcpRsp_success, kDcpRsp_invalidArgument, kDcpRsp_error
//--------------------------------------
#define DCP_NVM_OP_PROGRAM			4

typedef struct
{
	uint32		segment;			// segment to program
	uint32		offset;				// byte offset within segment
	uint32		flags;				// for future expansion
//	uint8		data[];				// data to program
}DCP_NVM_PROGRAM_IN;


//--------------------------------------
// READ command
// Read part of a section, if segment=0xffffffff read the complete flash
// Input:		DCP_NVM_READ_IN
// Output:		uint8[]
// Return code:	kDcpRsp_success, kDcpRsp_invalidArgument, kDcpRsp_error
//--------------------------------------
#define DCP_NVM_OP_READ				5

typedef struct
{
	uint32		segment;			// segment to read
	uint32		offset;				// byte offset within segment
	uint32		size;				// number of data to read (DCP_MAX_TRANSFER_SIZE)
}DCP_NVM_READ_IN;


//--------------------------------------
// CRC32 command
// Calculate CRC32 of part of a section
// Input:		DCP_NVM_CRC_IN
// Output:		DCP_NVM_CRC_OUT
// Return code:	kDcpRsp_success, kDcpRsp_invalidArgument, kDcpRsp_error
//
// Note: As the crc calculation over a large segment could take a long time and potentially block the
//		 DCP system it is up to the device how much of the CRC to calculate in each call.
//		 The host should continue to call this function until the complete CRC is calculated.
//		 A typical size used by the device i 1k.
//
//--------------------------------------
#define DCP_NVM_OP_CRC32			6

typedef struct
{
	uint32		segment;			// segment to check
	uint32		offset;				// offset into segment
	uint32		crc;				// crc base
	uint32		size;				// number of bytes from start offset of segment to calculate crc32 over
}DCP_NVM_CRC_IN;

typedef struct
{
	uint32		crc;				// accumulated crc
	uint32		size;				// number of bytes calculated in this call
}DCP_NVM_CRC_OUT;


//--------------------------------------
// LOCK command
// Lock or unlock a segment, certain segments might perform lengthy flash operations and should
//   be locked before performing operations in order to avoid time out.
// Input:		DCP_NVM_LOCK_IN
// Output:		none
// Return code:	kDcpRsp_success, kDcpRsp_invalidArgument, kDcpRsp_error
//--------------------------------------
#define DCP_NVM_OP_LOCK				7

typedef struct
{
	uint32		segment;			// segment to program
	uint32		lock;				// 1 to lock the segment, 0 to unlock
}DCP_NVM_LOCK_IN;



/***************************************************************************************************
 * DCP_CLASS_NAME
 * Handles getting names
 **************************************************************************************************/

//--------------------------------------
// GET command
// Get the name corresponding to a name index value
// Input:		uint16 name index
// Output:		null-terminated name
// Return code:	kDcpRsp_success, kDcpRsp_invalidArgument, kDcpRsp_error
//--------------------------------------
#define DCP_NAME_OP_GET				0



/***************************************************************************************************
 * DCP_CLASS_CLOCK
 * Handles setting and getting of clock sources and rates
 **************************************************************************************************/

//--------------------------------------
// SOURCES_GET command
// Get the list of available clock sources
// Input:		none
// Output:		array of DD2_CLOCK_SOURCE_ENTRY sources
// Return code:	kDcpRsp_success, kDcpRsp_error
//--------------------------------------
#define DCP_CLOCK_OP_SOURCES_GET	0


//--------------------------------------
// RATES_GET command
// Get the list of available sample rates
// Input:		none
// Output:		array of uint32 sample rates in Hz
// Return code:	kDcpRsp_success, kDcpRsp_error
//--------------------------------------
#define DCP_CLOCK_OP_RATES_GET		1


//--------------------------------------
// GET command
// Get the clock source and sample rate
// Input:		none
// Output:		DCP_CLOCK_GET
// Return code:	kDcpRsp_success, kDcpRsp_error
//--------------------------------------
#define DCP_CLOCK_OP_GET			2

typedef struct
{
	uint32		sampleRate;			// the selected sampleRate in Hz
	uint16		sourceId;			// the selected clock source
	uint16		activeSourceId;		// the actual clock source in use
}DCP_CLOCK_GET;


//--------------------------------------
// SET command
// Set the clock source and sample rate
// Input:		DCP_CLOCK_SET
// Output:		none
// Return code:	kDcpRsp_success, kDcpRsp_invalidArgument, kDcpRsp_error
//--------------------------------------
#define DCP_CLOCK_OP_SET			3

typedef struct
{
	uint32		sampleRate;			// the sampleRate in Hz
	uint16		sourceId;			// the clock source
	uint16		reserved;			// reserved - set to zero
}DCP_CLOCK_SET;


//--------------------------------------
// LOCK_STATUS_GET command
// Get the lock status
// Input:		none
// Output:		DCP_CLOCK_LOCK_STATUS_GET
// Return code:	kDcpRsp_success, kDcpRsp_error
//--------------------------------------
#define DCP_CLOCK_OP_LOCK_STATUS_GET	4

typedef enum
{
	eCLOCK_FLAG_LOCKED			= (1 << 0),		// lock/unlocked indicator
	eCLOCK_FLAG_UNLOCK_OCCURRED	= (1 << 1),		// indicates an unlock occurred since the last GET (cleared upon GET)
}CLOCK_FLAGS_ENUM;

typedef struct
{
	uint32		flags;				// clock flags
}DCP_CLOCK_LOCK_STATUS_GET;


//--------------------------------------
// MEASURED_RATE_GET command
// Get the measured sample rate
// Input:		none
// Output:		uint32 sample rate in Hz
// Return code:	kDcpRsp_success, kDcpRsp_error
//--------------------------------------
#define DCP_CLOCK_OP_MEASURED_RATE_GET	5



/***************************************************************************************************
 * DCP_CLASS_AUDIO
 * Handles getting the audio channel configuration
 **************************************************************************************************/

//--------------------------------------
// GLOBAL command
// Enquire about the audio streaming configuration of the device
// Input:		none
// Output:		DCP_AUDIO_GLOBAL
// Return code:	kDcpRsp_success, kDcpRsp_error
//--------------------------------------
#define DCP_AUDIO_OP_GLOBAL				0

typedef struct
{
	uint32		sortID;				// used for device sorting order
	uint32		flags;				// reserved - set to zero
	uint32		reserved[8];		// reserved - set to zero
}DCP_AUDIO_GLOBAL;


//--------------------------------------
// CONFIG_GET command
// Get the audio configuration for the specified rate
// Input:		uint8 kRate value
// Output:		DD2_AUDIO_CONFIG
// Return code:	kDcpRsp_success, kDcpRsp_invalidArgument, kDcpRsp_error
//--------------------------------------
#define DCP_AUDIO_OP_CONFIG_GET			1


//--------------------------------------
// PLAY_CHANS_GET command
// Get the playback audio channels for the specified rate
// Input:		DCP_AUDIO_CHANS_GET_IN
// Output:		array of DD2_AUDIO_CHANNEL
// Return code:	kDcpRsp_success, kDcpRsp_invalidArgument, kDcpRsp_error
//--------------------------------------
#define DCP_AUDIO_OP_PLAY_CHANS_GET		2


//--------------------------------------
// REC_CHANS_GET command
// Get the record audio channels for the specified rate
// Input:		DCP_AUDIO_PLAY_CHANS_GET_IN
// Output:		array of DD2_AUDIO_CHANNEL
// Return code:	kDcpRsp_success, kDcpRsp_invalidArgument, kDcpRsp_error
//--------------------------------------
#define DCP_AUDIO_OP_REC_CHANS_GET		3

typedef struct
{
	uint8		rate;				// kRate value
	uint8		reserved;			// reserved - set to zero
	uint16		startIndex;			// starting index to get
	uint16		num;				// number of channels to get
}DCP_AUDIO_CHANS_GET_IN;


//--------------------------------------
// STREAMING_ENABLE_SET command
// Set streaming enabled/disabled
// Input:		uint32	0 = disable, 1 = enable
// Output:		none
// Return code:	kDcpRsp_success, kDcpRsp_invalidArgument, kDcpRsp_error
//--------------------------------------
#define DCP_AUDIO_OP_STREAMING_ENABLE_SET	4



/***************************************************************************************************
 * DCP_CLASS_MIDI
 * Handles getting the MIDI port configuration
 **************************************************************************************************/

//--------------------------------------
// CAPS command
// Enquire about the MIDI capabilities
// Input:		none
// Output:		DD2_MIDI_CAPS
// Return code:	kDcpRsp_success, kDcpRsp_error
//--------------------------------------
#define DCP_MIDI_OP_CAPS			0


//--------------------------------------
// IN_PORTS_GET command
// Get the info for all MIDI in ports
// Input:		none
// Output:		array of DD2_MIDI_PORT
// Return code:	kDcpRsp_success, kDcpRsp_error
//--------------------------------------
#define DCP_MIDI_OP_IN_PORTS_GET	1


//--------------------------------------
// OUT_PORTS_GET command
// Get the info for all MIDI out ports
// Input:		none
// Output:		array of DD2_MIDI_PORT
// Return code:	kDcpRsp_success, kDcpRsp_error
//--------------------------------------
#define DCP_MIDI_OP_OUT_PORTS_GET	2



//**************************************************************************************************

/***************************************************************************************************
 * DCP NOTIFICATIONS
 * The DCP system supports up to 32 notifications from the device to the host. They are split into
 * groups.
 * DCP_SYSTEM_RESERVED	0-1 are reserved for the low level communication
 * DCP_TCAT_RESERVED	2-20 are reserved for the TCAT opcode system
 * DCP_USER				21-31 are free to use by vendor specific implementations
 **************************************************************************************************/

#define DCP_NOTIFY_USER_MASK		0xffe00000
#define DCP_NOTIFY_CLOCK_UPD		(1<<2)
#define DCP_NOTIFY_CLOCK_LOCK		(1<<3)
#define DCP_NOTIFY_AUDIO_UPD		(1<<4)
#define DCP_NOTIFY_MIDI_UPD			(1<<5)

#define	DCP_NOTIFY_USER1			0x00200000
#define	DCP_NOTIFY_USER2			0x00400000
#define	DCP_NOTIFY_USER3			0x00800000
#define	DCP_NOTIFY_USER4			0x01000000
#define	DCP_NOTIFY_USER5			0x02000000
#define	DCP_NOTIFY_USER6			0x04000000
#define	DCP_NOTIFY_USER7			0x08000000
#define	DCP_NOTIFY_USER8			0x10000000
#define DCP_NOTIFY_USER9			0x20000000
#define	DCP_NOTIFY_USER10			0x40000000
#define	DCP_NOTIFY_USER11			0x80000000



#if defined(__cplusplus)
} // extern "C"
} // namespace tcat
#endif

#endif //_DCPOPCODES_H_
