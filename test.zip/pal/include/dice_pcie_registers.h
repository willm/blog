//==============================================================================
//####TCAT-SOURCE-HEADER-BEGIN####
//
// This confidential and proprietary source may be used only as authorized
// by a licensing agreement from TC Applied Technologies.
//
// Copyright (c) 2014-2015 TC Applied Technologies
//                         a division of TC Group Americas Ltd.
//                         All rights reserved.
//
// Unauthorized use, duplication or distribution of this source is strictly
// prohibited by law.
//
// The entire notice above must be reproduced on all authorized copies and
// copies may only be made to the extent permitted by a licensing agreement
// from TC Applied Technologies.
//
//####TCAT-SOURCE-HEADER-END####
//==============================================================================
//
//	hardware register defines, see TB_Specification.pdf for details
//
//==============================================================================

#pragma once


#define TB_REG_BASE					0x0

#define FPGA_REVISION				(TB_REG_BASE + 0x000)
#define MAX_CHNLS					(TB_REG_BASE + 0x004)
#define MAX_BUF_SIZE				(TB_REG_BASE + 0x008)
#define SERIAL_NUM_LO				(TB_REG_BASE + 0x010)
#define SERIAL_NUM_HI				(TB_REG_BASE + 0x014)
#define STAT_CMD					(TB_REG_BASE + 0x018)
#define DEV_STAT_CMD				(TB_REG_BASE + 0x01C)

#define EXCEPT_INFO					(TB_REG_BASE + 0x100)
#define EXCEPT_INFO_EN				(TB_REG_BASE + 0x104)
#define BUF_SMPLS					(TB_REG_BASE + 0x108)
#define STREAM_CR					(TB_REG_BASE + 0x10C)
#define ENABLE_STREAMING			(TB_REG_BASE + 0x110)
#define EXCEPT_INFO_NC				(TB_REG_BASE + 0x114)

#define PLAY_INT_INFO				(TB_REG_BASE + 0x200)
#define PLAY_BUF_CHNLS				(TB_REG_BASE + 0x204)
#define PLAY_BUF_SIZE				(TB_REG_BASE + 0x208)
#define PLAY_REQ_THR				(TB_REG_BASE + 0x20C)
#define PLAY_DESC_LIST_LO			(TB_REG_BASE + 0x210)
#define PLAY_DESC_LIST_HI			(TB_REG_BASE + 0x214)
#define STAT_PLAY_MAX				(TB_REG_BASE + 0x218)
#define STAT_PLAY_MIN				(TB_REG_BASE + 0x21C)
#define STAT_PLAY_CUR_BUF			(TB_REG_BASE + 0x220)

#define REC_INT_INFO				(TB_REG_BASE + 0x300)
#define REC_BUF_CHNLS				(TB_REG_BASE + 0x304)
#define REC_BUF_SIZE				(TB_REG_BASE + 0x308)
#define REC_DESC_LIST_LO			(TB_REG_BASE + 0x310)
#define REC_DESC_LIST_HI			(TB_REG_BASE + 0x314)
#define STAT_REC_MAX				(TB_REG_BASE + 0x318)
#define STAT_REC_MIN				(TB_REG_BASE + 0x31C)
#define STAT_REC_CUR_BUF			(TB_REG_BASE + 0x320)

#define DEV2HOST_INT_INFO			(TB_REG_BASE + 0x400)
#define HOST2DEV_INT				(TB_REG_BASE + 0x408)
#define OWNER_ADDR_LO				(TB_REG_BASE + 0x410)
#define OWNER_ADDR_HI				(TB_REG_BASE + 0x414)

#define MIDI_CSR					(TB_REG_BASE + 0x500)
#define MIDI_CSR_SET				(TB_REG_BASE + 0x504)
#define MIDI_CSR_CLR				(TB_REG_BASE + 0x508)
#define MIDI_FIFO_WMARK				(TB_REG_BASE + 0x510)
#define MIDI_INFO					(TB_REG_BASE + 0x514)
#define MIDI_FIFO_DATA				(TB_REG_BASE + 0x58C)

#define STATS_NANOSECS_PER_BIT		2048
#define NUM_STAT_HISTOGRAM_BINS			10
#define PLAY_STAT_BINS_BASE			(TB_REG_BASE + 0x800)

#define REC_STAT_BINS_BASE			(TB_REG_BASE + 0x880)
#define DCP_COMMAND					(TB_REG_BASE + 0x8000)

#define DEBUG_BASE                  (TB_REG_BASE + 0x600)
#define NUM_DEBUG_REGS			    10

#define MAX_DESC                  (TB_REG_BASE + 0x020) // Maximnum number of 64bit 

//==============================================================================

// EXCEPT_INFO and EXCEPT_INFO_EN bit defines
#define kExceptInfo_RecBufInt			(1<<31)
#define kExceptInfo_PlayBufInt			(1<<30)
#define kExceptInfo_Dev2HostInt			(1<<29)
#define kExceptInfo_MidiInt				(1<<28)
#define kExceptInfo_AllErrorsMask		0x3f
#define kExceptInfo_RecIncomplete		(1<<5)
#define kExceptInfo_PlayIncomplete		(1<<4)
#define kExceptInfo_FatalErrorMask		0xf			// kEIFE_ defines below
#define kExceptInfo_Any                 ((kExceptInfo_RecBufInt|kExceptInfo_PlayBufInt|kExceptInfo_Dev2HostInt|kExceptInfo_MidiInt | kExceptInfo_FatalErrorMask))
#define kEIFE_NoError					0
#define kEIFE_RecFormat					1
#define kEIFE_RecUnderrun				2
#define kEIFE_RecMiss2					3
#define kEIFE_RecDescSeq				4
#define kEIFE_RecDescLen				5
#define kEIFE_RecDescFmt				6
#define kEIFE_PlayFormat				7
#define kEIFE_PlayUnderrun				8
#define kEIFE_PlayMiss2					9
#define kEIFE_PlayDescSeq				10
#define kEIFE_PlayDescLen				11
#define kEIFE_PlayDescFmt				12
#define kEIFE_NormatStop				15

// STREAM_CR bit defines
#define kStreamCr_PlayIntAtBufBoundary	(1<<0)
#define kStreamCr_RecIntAtBufBoundary	(1<<1)
#define kStreamCr_Play_Tlc_Tc_Shift		8
#define kStreamCr_Play_Tlc_Tc_Mask		0x7
#define kStreamCr_Play_Tlc_NoSnoop		(1<<11)
#define kStreamCr_Play_Tlc_RelaxedOrder	(1<<12)
#define kStreamCr_Rec_Tlc_Tc_Shift		8
#define kStreamCr_Rec_Tlc_Tc_Mask		0x7
#define kStreamCr_Rec_Tlc_NoSnoop		(1<<19)
#define kStreamCr_Rec_Tlc_RelaxedOrder	(1<<20)

// ENABLE_STREAMING bit defines
#define kEnableStreaming_Disable		0
#define kEnableStreaming_Enable			1

// PLAY_INT_INFO defines
#define kPlayIntInfo_Valid				(1<<31)		// valid - set if interrupt since last read
#define kPlayIntInfo_Double				(1<<30)		// double - set if more than one interrupt since last read
#define kPlayIntInfo_BufferNumShift		(1<<0)
#define kPlayIntInfo_BufferNumMask		(0xffff)	// the number of the last play buffer completed + 1

// REC_INT_INFO defines
#define kRecIntInfo_Valid				(1<<31)		// Valid -Set if interrupt since last read
#define kRecIntInfo_Double				(1<<30)		// Double - Set if more than one int since last read
#define kRecIntInfo_BufferNumShift		(1<<0)
#define kRecIntInfo_BufferNumMask		(0xffff)	// the number of the last record buffer completed + 1

// DEV2HOST_INT_INFO defines
#define kDev2HostIntInfo_DcpCmdAck		(1<<0)
#define kDev2HostIntInfo_DcpRspRdy		(1<<1)
#define kDev2HostIntInfo_DcpMask		0x3			// FIXME -- should be 0xf but the firmware is mistakenly using bits 2 & 3 for DCP category notifications

// HOST2DEV_INT defines
#define kHost2DevIntInfo_DcpCmdRdy		(1<<0)
#define kHost2DevIntInfo_DcpRspAck		(1<<1)
#define kHost2DevIntInfo_DcpMask		0xf

// MIDI_CSR, MIDI_CSR_SET, and MIDI_CSR_CLR bit defines
#define kMidiCsr_InFifoNotEmpty			(1<<1)
#define kMidiCsr_IntPendAck				(1<<3)
#define kMidiCsr_AutoIntEnable			(1<<4)
#define kMidiCsr_AutoInt				(1<<5)
#define kMidiCsr_MaxNumOutFifos			8
#define kMidiCsr_OutFifo_0_Free			(1<<16)
#define kMidiCsr_OutFifo_AnyFreeMask    (0x00ff0000)
#define kMidiCsr_OutFifo_AnyEnabledMask (0xff000000)
#define kMidiCsr_OutFifo_FreeShift      (16)
#define kMidiCsr_OutFifo_0_FreeEnable	(1<<24)
#define kMidiCsr_OutFifo_0_EnableShift	(24)

// MIDI_INFO bit defines
#define kMidiInfo_InFifoSizeShift		0
#define kMidiInfo_InFifoSizeMask		0x7			// 2^size = num of bytes
#define kMidiInfo_OutFifoSizeShift		4
#define kMidiInfo_OutFifoSizeMask		0xf			// 2^size = num of bytes
#define kMidiInfo_NumMidiPortsShift		8
#define kMidiInfo_NumMidiPortsMask		0x7			// num of MIDI ports 0 - 8

#define kMidiInfo_OutFifoLenShift       (24)		// shift
#define kMidiInfo_OutFifoLenMask        (3<<kMidiInfo_OutFifoLenShift)		// size bits in bit 24:25
#define kMidiInfo_OutFifoPortShift      (28)		// vport in bits 30:28
#define kMidiInfo_InFifoVPortShift      (28)		// vport in bits 30:28

#define kMidiBytesPerQuadlet (3)                    // PCIe 3 bytes per midi FIFO quadlet
//==============================================================================
