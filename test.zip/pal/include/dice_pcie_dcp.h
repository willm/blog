//==============================================================================
//####TCAT-SOURCE-HEADER-BEGIN####
//
// This confidential and proprietary source may be used only as authorized
// by a licensing agreement from TC Applied Technologies.
//
// Copyright (c) 2014-2015 TC Applied Technologies
//                         a division of TC Group Americas Ltd.
//                         All rights reserved.
//
// Unauthorized use, duplication or distribution of this source is strictly
// prohibited by law.
//
// The entire notice above must be reproduced on all authorized copies and
// copies may only be made to the extent permitted by a licensing agreement
// from TC Applied Technologies.
//
//####TCAT-SOURCE-HEADER-END####
//==============================================================================
//
//	DCP over PCIe, see TB_Specification.pdf for details
//
//==============================================================================

#pragma once

#include "tcat.h"
#include "dice_pcie_registers.h"

namespace tcat
{

#define kDcpPcieSpecVersion				1			// the version that this code supports

#define kDcpGlobalMagicNum				0x1810196604061973

struct DcpPcieGlobal
{
	uint64		magicNumber;
	uint32		version;
	uint32		versionCompat;
	uint32		maxTransferSize;
	uint32		maxSegmentSize;
	uint64		cmdAddr;				// for PCIe this is the offset into the BAR0 space
};


#define kDcpHead_OpcodeIndexMask		0xfff
#define kDcpHead_OpcodeIndexShift		0

#define kDcpHead_OpcodeCategoryMask		0xfff
#define kDcpHead_OpcodeCategoryShift	12

#define kDcpHead_Flag_FirstSegment		0x80000000

#define kDcpHead_SizeMask				0xffff
#define kDcpHead_SizeShift				0

#define kDcpHead_SeqNumMask				0xffff
#define kDcpHead_SeqNumShift			16



struct DcpPcieHeader
{
	uint32	flags_opcode;
	uint32	seq_sz;
	uint32	rsp_code;
	uint32	reserved;
};

class DcpPcieSegment
{
	// FIXME -- add constructors and set/get methods for header fields so kDcpHeader_ flags are only used within

public:
	DcpPcieHeader	head;
	uint32			data[1];
};


} // namespace tcat
