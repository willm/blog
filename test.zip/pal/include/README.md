PAL3
====

This is the third-generation of the platform abstraction layer to communicate with DCP and FCP-enabled devices.
It supports PCIe (Thunderbolt) and USB devices on both the Mac OS X and Windows platforms.

Prerequisites
-------------

### Mac OS X

- Xcode
- Automake: `brew install automake`
- Libtool: `brew install libtool`

### Windows

- Visual Studio 2013

OS X (XCode)
------------

1. Include Pal3.hpp and Pal3.cpp in your project, or the contents of 'common', 'usb', and 'pcie' directories for finer control
2. Add to your header search paths:
    - [DICE]/source/tdl/interface/public
    - [DICE]/source/include
    - [DICE]/source/driver/interface

Windows
-------

1. Include Pal3.hpp and Pal3.cpp in your project
2. Add the following include paths:
	- [DICE]\source\pal3
	- [DICE]\source\tdl\interface\public
	- [DICE]\source\include
	- [DICE]\source\driver\interface

Usage
-----

- Include "Pal3.hpp" in your source and add <DICE>/source/pal3 to the search path
- Create a system Delegate to be informed about devices coming and going

    ```
    class MySystemDelegate : public Pal::SystemDelegate
    {
        void deviceAdded(std::shared_ptr<Pal::Device> device) override;
        void deviceRemoved(std::shared_ptr<Pal::Device> device) override;
    };
    ```

- Create a Pal system
    ```
    std::shared_ptr<Pal::System> mySystem = Pal::System::createSystem(this)
    ```
- You'll need to call shutdown() before the application quits
    `mySystem->shutdown()`
- Create a DeviceDelegate to be notified about changes to devices
    ```
    class MyDeviceDelegate : public Pal::DeviceDelegate
    {
        void mount() override;
        void unmount() override;
    }
    ```
- Create a new device delegate when a device arrives. It might look something like this...
    ```
    void MySystemDelegate::deviceAdded(std::shared_ptr<Pal::Device> device)
    {
        std::lock_guard<std::mutex> lock{m_mutex};
        auto delegate = new MyDeviceDelegate{device};

        // To receive device notifications
        device->setDelegate(delegate);
        delegates.push_back(delegate);
    }
    ```


Caveats
-------

- Note that when using USB devices on OS X, only one PAL client can access the device at a time
