/*
 *  USBDefs.h
 *  FocusriteUSB2Audio
 *
 *  Created by Nick Dowell on 15/11/2010.
 *  Copyright 2010 __MyCompanyName__. All rights reserved.
 *
 */

enum {
    DEVICE									= 0x01,
    CONFIGURATION							= 0x02,
#ifndef WINVER
    STRING									= 0x03,
#endif
    //INTERFACE								= 0x04,
    ENDPOINT								= 0x05,
	DEVICE_QUALIFIER						= 0x06,
	OTHER_SPEED_CONFIGURATION				= 0x07,
	INTERFACE_ASSOCIATION					= 0x0B
};

enum {
    // For descriptor type
    CS_UNDEFINED							= 0x20,
    CS_DEVICE								= 0x21,
    CS_CONFIGURATION						= 0x22,
    CS_STRING								= 0x23,
    CS_INTERFACE							= 0x24,
    CS_ENDPOINT								= 0x25
};

enum {
	// Audio Interface Class Code
    AUDIO									= 0x01
};

enum {
	// Audio Interface Subclass Codes
	SUBCLASS_UNDEFINED						= 0x00,
    AUDIOCONTROL							= 0x01,
    AUDIOSTREAMING							= 0x02,
	MIDISTREAMING							= 0x03,
    APPLICATION_SPECIFIC                    = 0xFE,
	VENDOR_SPECIFIC							= 0xff
};

enum {
	// A.9 Audio Class-Specific AC Interface Descriptor Subtypes
	AC_DESCRIPTOR_UNDEFINED					= 0x00,
	HEADER									= 0x01,
	INPUT_TERMINAL							= 0x02,
	OUTPUT_TERMINAL							= 0x03,
	MIXER_UNIT								= 0x04,
	SELECTOR_UNIT							= 0x05,
	FEATURE_UNIT							= 0x06,
	EFFECT_UNIT								= 0x07,
	PROCESSING_UNIT							= 0x08,
	EXTENSION_UNIT							= 0x09,
	CLOCK_SOURCE							= 0x0A,
	CLOCK_SELECTOR							= 0x0B,
	CLOCK_MULTIPLIER						= 0x0C,
	SAMPLE_RATE_CONVERTER					= 0x0D
};

enum {
    // Audio Class-specific endpoint descriptor subtypes
    DESCRIPTOR_UNDEFINED					= 0x00,
    EP_GENERAL								= 0x01
};

enum {
    // Audio Stream (AS) interface descriptor subtypes
    AS_DESCRIPTOR_UNDEFINED					= 0x00,
    AS_GENERAL								= 0x01,
    FORMAT_TYPE								= 0x02,
    FORMAT_SPECIFIC							= 0x03
};

enum {
	// A.14 Audio Class-Specific Request Codes
	REQUESET_CODE_UNDEFINED					= 0x00,
	CUR										= 0x01,
	RANGE									= 0x02,
	MEM										= 0x03
};

enum {
	// A.17.1 Clock Source Control Selectors
	CS_CONTROL_UNDEFINED					= 0x00,
	CS_SAM_FREQ_CONTROL						= 0x01,
	CS_CLOCK_VALID_CONTROL					= 0x02
};

enum {
	// A.17.2 Clock Selector Control Selectors
	CX_CONTROL_UNDEFINED					= 0x00,
	CX_CLOCK_SELECTOR_CONTROL				= 0x01
};

enum {
	// A.17.14 Endpoint Control Selectors 
	EP_CONTROL_UNDEFINED					= 0x00, 
	EP_PITCH_CONTROL						= 0x01, 
	EP_DATA_OVERRUN_CONTROL					= 0x02, 
	EP_DATA_UNDERRUN_CONTROL				= 0x03 
};

// USB Device Class Definition for Audio Data Formats Release 2.0
enum {
	// Table A-1: Format Type Codes
    FORMAT_TYPE_UNDEFINED					= 0x00,
    FORMAT_TYPE_I							= 0x01,
    FORMAT_TYPE_II							= 0x02,
    FORMAT_TYPE_III							= 0x03,
    FORMAT_TYPE_IV							= 0x04,
    EXT_FORMAT_TYPE_I						= 0x05,
    EXT_FORMAT_TYPE_II						= 0x06,
    EXT_FORMAT_TYPE_III						= 0x07
};

enum {
    // Table A-2: Audio Data Format Type I Bit Allocations
    PCM										= 0x00000001,
    PCM8									= 0x00000002,
    IEEE_FLOAT								= 0x00000004,
    ALAW									= 0x00000008,
    MULAW									= 0x00000010,
	TYPE_I_RAW_DATA							= 0x80000000
};

#ifdef WINVER
typedef UCHAR UInt8;
typedef ULONG32 UInt32;
#pragma pack(push)
#pragma pack(1)
#endif

// Table 4-27: Class-Specific AS Interface Header Descriptor
typedef struct ASInterfaceDescriptor {
	UInt8									bLength;
	UInt8									bDescriptorType;
	UInt8									bDescriptorSubtype;
	UInt8									bTerminalLink;
	UInt8									bmControls;
	UInt8									bFormatType;
	UInt8									bmFormats[4];			// Not PPC aligned
	UInt8									bNrChannels;
	UInt8									bmChannelConfig[4];		// Not PPC aligned
	UInt8									iChannelNames;
} ASInterfaceDescriptor, *ASInterfaceDescriptorPtr;

// USB Device Class Definition for Audio Data Formats Release 2.0

// Table 2-2: Type I Format Type Descriptor 
typedef struct ASFormatTypeIDescriptor {
    UInt8									bLength;
    UInt8									bDescriptorType;
    UInt8									bDescriptorSubtype;
    UInt8									bFormatType;
    UInt8									bSubslotSize;
    UInt8									bBitResolution;
} ASFormatTypeIDescriptor;

typedef struct ASFormatTypeIDescriptorEx {
    UInt8									bLength;
    UInt8									bDescriptorType;
    UInt8									bDescriptorSubtype;
    UInt8									bFormatType;
    UInt8									bSubslotSize;
    UInt8									bBitResolution;
    UInt32									dMaxSampleRate;
} ASFormatTypeIDescriptorEx;

// Table 4-6: Clock Source Descriptor
typedef struct ACClockSourceDescriptor {
	UInt8									bLength;
    UInt8									bDescriptorType;
    UInt8									bDescriptorSubtype;
    UInt8									bClockID;
    UInt8									bmAttributes;
    UInt8									bmControls;
    UInt8									bAssocTerminal;
    UInt8									iClockSource;
} ACClockSourceDescriptor;

#ifdef WINVER
#pragma pack(pop)
#endif
