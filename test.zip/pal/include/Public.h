//
// 
#include <initguid.h>   
#pragma once


#if 0
typedef struct StreamFormat{
    UINT32    Samplerate;
    UINT32    HwBufferSize;
    UINT32    PlayChannels;
    UINT32    SafetyPlay;
    UINT32    RecChannels;
    UINT32    SafetyRecord;
    UINT32    ClockSource;       // Bits define sync source - EXACTLY one should be set 

}STREAMFORMAT, *PSTREAMFORMAT;
#endif




