//==============================================================================
//####TCAT-SOURCE-HEADER-BEGIN####
//
// This confidential and proprietary source may be used only as authorized
// by a licensing agreement from TC Applied Technologies.
//
// Copyright (c) 2014 TC Applied Technologies
//                         a division of TC Group Americas Ltd.
//                         All rights reserved.
//
// Unauthorized use, duplication or distribution of this source is strictly
// prohibited by law.
//
// The entire notice above must be reproduced on all authorized copies and
// copies may only be made to the extent permitted by a licensing agreement
// from TC Applied Technologies.
//
//####TCAT-SOURCE-HEADER-END####
//==============================================================================

#pragma once

#include "dcp_opcodes.h"

#if defined(__cplusplus)
namespace tcat
{
extern "C" {
#endif


#define kTCAT_DICE_DEVICES						5


/**************************************************************************************************/

struct tDriverNotification
{
	uint32		busNotification;
	uint32		deviceDcpNotification;				///< valid if kBusNotification_DeviceDcpNotification
	uint64		deviceID;							///< deviceID of device that the deviceDcpNotification came from
};


enum
{
	kBusNotification_DeviceArrived			= (1 << 0),
	kBusNotification_DeviceRemoved			= (1 << 1),
	kBusNotification_BusReset				= (1 << 2),
	kBusNotification_ConfigChanged			= (1 << 3),
	kBusNotification_InterfaceReady			= (1 << 4),
	kBusNotification_DeviceDcpNotification	= (1 << 5),
	kBusNotification_MidiInputReceived		= (1 << 6),

	kBusNotification_NumofNotifications
};



/***************************************************************************************************
 * DCP_CLASS_PAL
 *
 **************************************************************************************************/

enum
{
	kDcpPAL_Version					= 0xF001,	// this API version
	kDcpPAL_MinCompatibleAPIVersion	= 0xF001,	// minimum API version that is still compatible with this version
};

//----------------------------------------------------------
// Version command
// Input:		none
// Output:		none
// Return code:	kDcpRsp_success or kDcpRsp_error
//----------------------------------------------------------
#define kDcpPAL_Op_Version					0

struct tDcpPAL_Version
{
	uint32		ioctlAPIVersion;				// set to kDcpPAL_Version
	uint32		ioctlMinCompatibleAPIVersion;	// set to kDcpPAL_MinCompatibleAPIVersion
};


//----------------------------------------------------------
// Open command
// Input:		none
// Output:		none
// Return code:	kDcpRsp_success or kDcpRsp_error
//----------------------------------------------------------
#define kDcpPAL_Op_Open						1


//----------------------------------------------------------
// Close command
// Input:		none
// Output:		none
// Return code:	kDcpRsp_success or kDcpRsp_error
//----------------------------------------------------------
#define kDcpPAL_Op_Close					2


//----------------------------------------------------------
// Notifications command  (only used by OS X)
// Input:		tDcpPAL_Notifications
// Output:		none
// Return code:	kDcpRsp_success or kDcpRsp_error
//----------------------------------------------------------
#define kDcpPAL_Op_Notifications			3

struct tDcpPAL_Notifications
{
	uint64		callbackPtr;
	uint64		refConPtr;
	uint64		magicVal;
};


//----------------------------------------------------------
// BusConfigGet command
// Input:		none
// Output:		tDcpPAL_BusConfigGet
// Return code:	kDcpRsp_success or kDcpRsp_error
//----------------------------------------------------------
#define kDcpPAL_Op_BusConfigGet				4

struct tDcpPAL_BusConfigGet
{
	uint64		masterDeviceID;						///< The device ID of the sync master device
	uint32		clockSourceID;
	uint32		sampleRate;
	uint32		opMode;
	uint32		asioBufferSize;

	uint32		minAsioBufferSize;
	uint32		maxAsioBufferSize;

	uint32		numPlayChannels;					///< Total number of audio output channels (host -> device)
	uint32		numRecordChannels;					///< Total number of audio input channels (device -> host)

	uint64		deviceIDs[kTCAT_DICE_DEVICES];		///< Device dependent information
	uint32		numDevices;							///< Number of devices
	uint32		padding_01;
};


//----------------------------------------------------------
// SetSampleRate command
// Input:		uint32
// Output:		none
// Return code:	kDcpRsp_success or kDcpRsp_error
//----------------------------------------------------------
#define kDcpPAL_Op_SetSampleRate			5


//----------------------------------------------------------
// SetClockSource command
// Input:		uint32
// Output:		none
// Return code:	kDcpRsp_success or kDcpRsp_error
//----------------------------------------------------------
#define kDcpPAL_Op_SetClockSource			6


//----------------------------------------------------------
// SetOpMode command
// Input:		uint32
// Output:		none
// Return code:	kDcpRsp_success or kDcpRsp_error
//----------------------------------------------------------
#define kDcpPAL_Op_SetOpMode				7


//----------------------------------------------------------
// SetMasterDevice command
// Input:		uint64
// Output:		none
// Return code:	kDcpRsp_success or kDcpRsp_error
//----------------------------------------------------------
#define kDcpPAL_Op_SetMasterDevice			8


//----------------------------------------------------------
// SetAsioBufferSize command (Windows only)
// Input:		uint32
// Output:		none
// Return code:	kDcpRsp_success or kDcpRsp_error
//----------------------------------------------------------
#define kDcpPAL_Op_SetAsioBufferSize		9


//----------------------------------------------------------
// DeviceConfigGet command
// Input:		none
// Output:		tDcpPAL_DeviceConfigGet
// Return code:	kDcpRsp_success or kDcpRsp_error
//----------------------------------------------------------
#define kDcpPAL_Op_DeviceConfigGet			10

struct tDcpPAL_DeviceConfigGet
{
	uint32		sampleRate;
	uint32		measuredSampleRate;
	uint16		clockSourceID;
	uint16		clockActiveSourceID;
	uint32		clockLocked;
};

//----------------------------------------------------------
// CanSampleRate command
// Input:		uint32
// Output:		uint32
// Return code:	kDcpRsp_success or kDcpRsp_error
//----------------------------------------------------------
#define kDcpPAL_Op_CanSampleRate			11

//----------------------------------------------------------
// GetAsioBufferSizes command
// Input:		uint32
// Output:		uint32[] of buffer sizes
// Return code:	kDcpRsp_success or kDcpRsp_error
//----------------------------------------------------------
#define kDcpPAL_Op_GetAsioBufferSizes			12

// ----------------------------------------------------------
// Query AudioClientManager for #of runing clients
// Input:		none
// Output:		uint32: number of running audio clients (wdm+asio)
// Return code:	kDcpRsp_success or kDcpRsp_error
//----------------------------------------------------------
#define kDcpPAL_Op_GetNumAudioClients     	            13

//----------------------------------------------------------
// GetPcieStats command
// Input:		uint32  (deviceID)
// Output:		tDcpPAL_GetPcieStats
// Return code:	kDcpRsp_success or kDcpRsp_error
//----------------------------------------------------------
#define kDcpPAL_Op_GetPcieStats				500

struct tDcpPAL_GetPcieStats
{
	uint32			statCmd;
	uint32			devStatCmd;

	uint32			playIncompleteExceptions;
	uint32			recIncompleteExceptions;

	uint32			playCurBuf;
	uint32			recCurBuf;

	uint32			statsNanoSecsPerBit;
	uint32			playMax;
	uint32			playMin;
	uint32			numPlayStatBins;
	uint32			playStatBins[16];
	uint32			recMax;
	uint32			recMin;
	uint32			numRecStatBins;
	uint32			recStatBins[16];
};

//**************************************************************************************************

#if defined(__cplusplus)
} // extern "C"
} // namespace tcat
#endif



//**************************************************************************************************
