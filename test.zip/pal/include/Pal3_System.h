//
//  System.h
//  pal
//
//  Created by Joe Noel on 07/10/2015.
//  Copyright (c) 2015 Focusrite Audio Engineering Ltd. All rights reserved.
//

#ifndef __pal__System__
#define __pal__System__

#include <iostream>
#include <memory>

#if defined (_WIN32)
#if defined (PALBUILD)
#define DLLLINKAGE  __declspec(dllexport)
#else
#define DLLLINKAGE  __declspec(dllimport)
#endif
#else
#define DLLLINKAGE
#endif
namespace Pal
{
    class Device;
    
    /**
     Delegate class for the system object. This will probably be inherited by some manager class that becomes aware of 
     devices coming and going. The callback functions here might be called on any thread so should be thread safe
     */
    class DLLLINKAGE SystemDelegate
    {
    public:
        virtual ~SystemDelegate() = default;
        
        /**
         Notification that a device has been added to the system
         
         Might be called from any thread
         */
        virtual void deviceAdded(std::shared_ptr<Device>) {}
        
        /**
         Notification that a device has been removed from the system. You should stop using the object.
         
         Might be called from any thread
         The system has stopped using this object by now, when you stop using it, it will be deleted
         */
        virtual void deviceRemoved(std::shared_ptr<Device>) {}
    };
    
    /**
     Root object for creating a representation of all of the PAL-supported devices on a system
     
     To become aware of devices arriving and disappearing, override the SystemDelegate class
     and pass it in as a parameter
     
     Create a system by calling the factory function:
     
     auto system = Pal::System::createSystem(delegate);
     
     */
    class DLLLINKAGE System
    {
    public:
        virtual                                 ~System() = default;
    
        /**
         Create the system
		 shutdown() must be called before the application's main() has completed
         */
        static std::shared_ptr<System>          createSystem(SystemDelegate* delegate, bool requiresUSB = true);

		/**
		Shutdown the system

		This must be called before main() has completed as, on some Windows systems,
		it will not be able to clean up its threads after this point and it will hang
		*/
        virtual void                            shutdown() = 0;
    };
}

#endif /* defined(__pal__System__) */
