//==============================================================================
//####TCAT-SOURCE-HEADER-BEGIN####
//
// This confidential and proprietary source may be used only as authorized
// by a licensing agreement from TC Applied Technologies.
//
// Copyright (c) 2014-2015 TC Applied Technologies
//                         a division of TC Group Americas Ltd.
//                         All rights reserved.
//
// Unauthorized use, duplication or distribution of this source is strictly
// prohibited by law.
//
// The entire notice above must be reproduced on all authorized copies and
// copies may only be made to the extent permitted by a licensing agreement
// from TC Applied Technologies.
//
//####TCAT-SOURCE-HEADER-END####
//==============================================================================

#pragma once
#include "dcp_opcodes.h"
#include "dice_pcie_registers.h"

#if defined(__cplusplus)
namespace tcat
{
extern "C" {
#endif
    //	the struct in the status buffer
    struct DicePCIeDriverStatus
    {
        volatile uint64		mSampleTime;
        volatile uint64		mHostTime;
    };

    enum
    {
        kNotificationMsg_StreamConfigChanged,
        kNotificationMsg_StreamingAborted,
        kNotificationMsg_ClockLocked,
        kNotificationMsg_SamplerateChanged,
    };



/***************************************************************************************************
 * DCP_CLASS_WIN_DRIVER_PRIVATE
 *
 **************************************************************************************************/

enum
{
	kDcpODP_Version					= 0xF000,	// this API version
	kDcpODP_MinCompatibleAPIVersion	= 0xF000,	// minimum API version that is still compatible with this version
};

//----------------------------------------------------------
// Version command
// Input:		none
// Output:		none
// Return code:	kDcpRsp_success or kDcpRsp_error
//----------------------------------------------------------
#define kDcpODP_Op_Version					0

struct tDcpODP_Version
{
	uint32		ioctlAPIVersion;				// set to kDcpODP_Version
	uint32		ioctlMinCompatibleAPIVersion;	// set to kDcpODP_MinCompatibleAPIVersion
};


//----------------------------------------------------------
// Open command
// Input:		none
// Output:		none
// Return code:	kDcpRsp_success or kDcpRsp_error
//----------------------------------------------------------
#define kDcpODP_Op_Open						1


//----------------------------------------------------------
// Close command
// Input:		none
// Output:		none
// Return code:	kDcpRsp_success or kDcpRsp_error
//----------------------------------------------------------
#define kDcpODP_Op_Close					2


//----------------------------------------------------------
// Notifications command
// Input:		tDcpODP_Notifications
// Output:		none
// Return code:	kDcpRsp_success or kDcpRsp_error
//----------------------------------------------------------
#define kDcpODP_Op_Notifications			3

struct tDcpODP_Notifications
{
	uint64		callbackPtr;
	uint64		refConPtr;
	uint64		magicVal;
};


//----------------------------------------------------------
// GetConfig command
// Input:		none
// Output:		tDcpODP_GetConfig
// Return code:	kDcpRsp_success or kDcpRsp_error
//----------------------------------------------------------
#define kDcpODP_Op_GetConfig				4

struct tDcpODP_GetConfig
{
	uint32		sampleRate;
	uint32		clockSourceID;
	uint32		hwBufferSize;
	uint32		appBufferSize;
};


//----------------------------------------------------------
// SetConfig command
// Input:		tDcpODP_SetConfig
// Output:		none
// Return code:	kDcpRsp_success or kDcpRsp_error
//----------------------------------------------------------
#define kDcpODP_Op_SetConfig				5

struct tDcpODP_SetConfig
{
	uint32		sampleRate;
	uint16		clockSourceID;
	uint32		hwBufferSize;
	uint32		appBufferSize;
	uint32		numPlayChannels;
	uint32		numRecordChannels;
};


//----------------------------------------------------------
// EnableStreaming command
// Input:		uint32
// Output:		none
// Return code:	kDcpRsp_success or kDcpRsp_error
//----------------------------------------------------------
#define kDcpODP_Op_EnableStreaming			6

//----------------------------------------------------------
// ConfigureStreaming command
// Input:		tDcpODP_Op_ConfigureStreaming
// Output:		none
// Return code:	kDcpRsp_success or kDcpRsp_error
//----------------------------------------------------------
#define kDcpODP_Op_SetStreamingConfig	    7
#define kDcpODP_Op_GetStreamingConfig       8
#define kDcpODP_Flag_SingleBufferSwitch     (1) // Adjust low-level stream size so that only a single bufferswitch will ever be invoked per stream completion
struct tDcpODP_Op_ConfigureStreaming
{
    uint32      sampleRate;     // Used only for calculation purposes
    uint16      clockSourceID;
    uint32		hwBufferSize;
    uint32		appBufferSize;
    uint32		numPlayChannels;
    uint32		numRecordChannels;
    uint32      flags;
};
//----------------------------------------------------------
// GetStreamInfo command
// Input:		PDEVICESTREAMINFO
// Output:		none
// Return code:	kDcpRsp_success or kDcpRsp_error
//----------------------------------------------------------
#define kDcpODP_Op_GetStreamInfo	        9
// Struct defined in DriverInterface.h


//----------------------------------------------------------
// SetSafetyOffsets command
// Input:		tDcpODP_Op_SetSafety
// Output:		none
// Return code:	kDcpRsp_success or kDcpRsp_error
//----------------------------------------------------------
#define kDcpODP_Op_SetSafety	            10

struct tDcpODP_Op_SetSafety
{
    int32      playSafety;     // Used only for calculation purposes
    int32		recSafety;
};
//----------------------------------------------------------
// SetSafetyOffsets command
// Input:		tDcpODP_Op_SetSafety
// Output:		none
// Return code:	kDcpRsp_success or kDcpRsp_error
//----------------------------------------------------------


#define kDcpODP_Op_GetStreamInfos	    11
// uses DeviceStreamInfo_t


#define kDcpODP_PAL_Listen           12


// ----------------------------------------------------------
// GetLatencies command
// Input:		none
// Output:		kDcpODP_Op_GetDeviceLatencies
// Return code:	kDcpRsp_success or kDcpRsp_error
//----------------------------------------------------------
#define kDcpODP_Op_GetDeviceLatencies	            (13)
struct tDcpODP_Op_DeviceLatencies
{
    int32       sr;
    int32       buffSize;
    int32       play;     // Used only for calculation purposes
    int32	    record;
};

// ----------------------------------------------------------
// StartMidiOut command
// Input:		uint32 - port
// Output:		none
// Return code:	kDcpRsp_success or kDcpRsp_error
//----------------------------------------------------------
#define kDcpODP_Op_SetMidiOutStart	            (14)

// ----------------------------------------------------------
// SetMidiEnable command
// Input:		UINT32: bit31 = enable, bit 0-7 port
// Output:		none
// Return code:	kDcpRsp_success or kDcpRsp_error
//----------------------------------------------------------
#define kDcpODP_Op_SetMidiEnable	            (15)

// ----------------------------------------------------------
// SendMidiMsg command
// Input:		uint32 : |31         |30        |29:4   |3:0       |
//                       |enable=1   |output=1  |unused |port:0-7  |
// Output:		none
// Return code:	kDcpRsp_success or kDcpRsp_error
//----------------------------------------------------------
#define kDcpODP_Op_SetMidiEnable_bEnable (1<<31)
#define kDcpODP_Op_SetMidiEnable_bOutput (1<<30)
#define kDcpODP_Op_SetMidiEnable_nPortMask (7)

#define kDcpODP_Op_SendMidiMsg	            (16)
// Send 1 - 3 bytes midi data using the format spefieid in CH6 of TB_Specification.docx:
/*
Bit7:0      MIDI Byte0 if present
Bit15:8     MIDI Byte1 if present
Bit23:16    MIDI Byte2 if present
Bit25:24    Number of bytes in this word (0-3) 
Bit30:28    Virtual MIDI stream no.
*/

// Set the lower device's friendly name visible in device manager 
//----------------------------------------------------------
// GetPcieStats command
// Input:		tDcpODP_SetDeviceName
// Output:		none
// Return code:	kDcpRsp_success or kDcpRsp_error
//----------------------------------------------------------
#define kDcpODP_Op_SetDeviceName	            (17)
struct tDcpODP_SetDeviceName
{
    void*	puDesc;
    void*	puName;
};

// Query for USB-specific device info 
//----------------------------------------------------------
// GetDeviceInfo command
// Input:		tDcpODP_SetDeviceName
// Output:		none
// Return code:	kDcpRsp_success or kDcpRsp_error
//----------------------------------------------------------
#define kDcpODP_Op_GetDeviceInfo	            (18)
typedef struct 
{
    uint32          vid;
    uint32          pid;
    uint32          idProduct;  // Used with getName DCP command
	uint32			modelHash;	// Guranteed to be unique across all produc lines - vid pid cannot be used since all tbt devices are 1cb5:0002 currently and are differentiated by app_space values
    uint32          verFirmware;
    uint16          verDrvMaj;
    uint16          verDrvMin;
    uint16          verDrvSub;
    uint16          verDrvBld;
//ammend with fixed-length string data here
	char			sManufacturer[64];
	char			sDeviceName[64];
	char			sSerial[64];
}tDcpODP_GetDeviceInfo;

//----------------------------------------------------------
// StreamConnect command
// Input:		none (implicit process of caller)
// Output:		tDcpODP_StreamConnect
// Return code:	kDcpRsp_success or kDcpRsp_error
//----------------------------------------------------------
#define kDcpODP_StreamConnect				(19)

//----------------------------------------------------------
// StreamDisconnect command
// Input:		none (implicit process of caller)
// Output:		tDcpODP_StreamConnect
// Return code:	kDcpRsp_success or kDcpRsp_error
//----------------------------------------------------------
#define kDcpODP_StreamDisconnect				(20)


// ----------------------------------------------------------
// QueuMidiEvt command
// Input:		PDMUS_KERNEL_EVENT
// Output:		none
// Return code:	kDcpRsp_success or kDcpRsp_error
//----------------------------------------------------------
#define kDcpODP_Op_QMidiEvt     	            (21)


// ----------------------------------------------------------
// UsbaudioControlRequest command (for supporting Scarlett MixControl)
// Input:		USBAudioControlRequest_t
// Output:		none
// Return code:	kDcpRsp_success or kDcpRsp_error
//----------------------------------------------------------
#define kDcpODP_Op_UsbAudioControlRequest     	            (22)
typedef struct
{
    UCHAR dir;
    UCHAR entityId;
    UCHAR controlSel;
    UCHAR chOrMix;
    UCHAR request;
}tDcpODP_USBAudioControlRequest;

// ----------------------------------------------------------
// UsbGetDescriptor command (for supporting Scarlett MixControl)
// Input:		tDcpODP_UsbGetDescriptor
// Output:		none
// Return code:	kDcpRsp_success or kDcpRsp_error
//----------------------------------------------------------
#define kDcpODP_Op_UsbGetDescriptor     	            (23)
typedef struct
{
    UCHAR   type;
    UCHAR   index;
    UINT16  lang;
}tDcpODP_UsbGetDescriptor;

// ----------------------------------------------------------
// UsbClockSources request (for supporting Scarlett MixControl)
// Input:		none
// Output:		tDcpODP_UsbGetClockSources
// Return code:	kDcpRsp_success or kDcpRsp_error
//----------------------------------------------------------
#define kDcpODP_Op_GetClockSources     	            (24)
typedef struct 
{
	ULONG ClockSourceIndex;
	CHAR ClockSourceName[32];
	UCHAR ClockSourceEntityID;
	UCHAR ClockSelectorEntityID;
	UCHAR iClockSourceName;
	ULONG Flags;
} kDcpODP_GetClockSources;

// ----------------------------------------------------------
// UsbControlRequest command (for supporting DFU)
// Input:		USBControlRequest_t
// Output:		none
// Return code:	kDcpRsp_success or kDcpRsp_error
//----------------------------------------------------------
#define kDcpODP_Op_UsbControlRequest     	            (25)    //USB_DEFAULT_PIPE_SETUP_PACKET

// ----------------------------------------------------------
// UsbPortCycle command (for supporting ATE)
// Input:		uint32 portInfo
// Output:		none
// Return code:	kDcpRsp_success or kDcpRsp_error
//----------------------------------------------------------
#define kDcpODP_Op_UsbPortCycle     	            (26)    //Cycle Current USB Port

// ----------------------------------------------------------
// ControlMSDMode command (for Gen3 Mass Storage Device Mode)
// Input:		uint32 1=set MSDMode ON, 0=clear MSDMode, -1= return MSDMode
// Output:		uint32 0=MSDOff, 1=MSDON.  0 will be returned for devices with no MSD support
// Return code:	kDcpRsp_success or kDcpRsp_error
//----------------------------------------------------------
#define kDcpODP_Op_MsdControl     	            (27)    // MSDn mode set / get


// ----------------------------------------------------------
// WdmPairs command (for wdm filter pair control)
// Input:		uint32 0=no change to wdm pairs, 1+= set wdmpairs
// Output:		uint32 always return current wdmpairs bitmap
// Return code:	kDcpRsp_success or kDcpRsp_error
//----------------------------------------------------------
#define kDcpODP_Op_WdmPairs     	            (28)    // WDM input & output filter control

// ----------------------------------------------------------
// bugCheck command - force a Dbeugger breakpoint in the swroot driver (BSOD in retail builds)
// Input:		none
// Output:		none
// Return code:	none
//----------------------------------------------------------
#define kDcpODP_Op_BugCheck     	            (29)    // Force debugger breakpoint

//----------------------------------------------------------
// GatherPcieStats command
// Input:		uint32  (deviceID)
// Output:		kDcpODP_GetPcieStats
// Return code:	kDcpRsp_success or kDcpRsp_error
//----------------------------------------------------------
#define kDcpODP_Op_GetPcieStats				500

// Return a dcp notifiction and response in the passed user buffer if large enough to hold 
//----------------------------------------------------------
// GetPcieStats command
// Input:		uint32  (deviceID)
// Output:		kDcpODP_GetPcieStats
// Return code:	kDcpRsp_success or kDcpRsp_error
//----------------------------------------------------------
#define kDcpODP_Op_GetPcieStats				500

typedef struct tDcpODP_GetPcieStats_t
{
    uint32			cbSize;			// 0 == success
    uint32          bins;           // All bins are the same size
    uint32			statCmd;
    uint32			devStatCmd;

    uint32			statsNanoSecsPerBin;
    uint32			playMax;
    uint32			playMin;
    uint32			playStatBins[16];

    uint32			recMax;
    uint32			recMin;
    uint32			recStatBins[16];

    // Add wzd
    uint32			dpcNanoSecsPerBin;
    uint32          dpcLatencyAvg_uS;
    uint32          dpcLatencyMax_uS;
    uint32          dpcLatencies_uS[16];

    uint32          dpcDurationAvg_uS;
    uint32          dpcDurationMax_uS;
    uint32          dpcDurations_uS[16];
    uint32			playIncompleteExceptions;
    uint32			playDescUnderrunExceptions;
    uint32          playDoubleExceptions;
    uint32		    recIncompleteExceptions;
    uint32			recDescUnderrunExceptions;
    uint32          recDoubleExceptions;

    // Add PCIe register read stats
    uint32			regssNanoSecsPerBin;
    uint32          pcieRegDurations_uS[16];
    uint32          pcieRegDurationAvg_uS;
    uint32          pcieRegDurationMax_uS;
    uint64          avgDpcCallbackMargin;

}tDcpODP_GetPcieStats;

//----------------------------------------------------------
// GetUsbStats command
// Input:		uint32  (deviceID)
// Output:		kDcpODP_GetPcieStats
// Return code:	kDcpRsp_success or kDcpRsp_error
//----------------------------------------------------------
#define kDcpODP_Op_GetUsbStats				600

struct tDcpODP_GetUsbStats
{
    uint32			statCmd;
    uint32			devStatCmd;

    uint32			playIncompleteExceptions;
    uint32			recIncompleteExceptions;

    uint32			playCurBuf;
    uint32			recCurBuf;

    uint32			statsNanoSecsPerBit;
    uint32			playMax;
    uint32			playMin;
    uint32			numPlayStatBins;
    uint32			playStatBins[16];
    uint32			recMax;
    uint32			recMin;
    uint32			numRecStatBins;
    uint32			recStatBins[16];
};


#if defined(__cplusplus)
} // extern "C"
} // namespace tcat
#endif

